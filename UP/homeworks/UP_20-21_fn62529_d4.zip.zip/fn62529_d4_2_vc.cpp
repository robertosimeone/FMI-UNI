/**
*
* Solution to homework assignment 4
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 2
* @compiler VC
*
*/
#include <iostream>
#include <iomanip>
using namespace std;

//FIX INPUT FOR P1,P,Q,Q1
void validateTableDimensions(int& input, const int  LOWER_LIMIT, const int UPPER_LIMIT) {
	do {
		cin >> input;
	} while (input <= 3 || input>200);
}
//function that validates the input for turns
void validateTurns(int& turns,const int  LOWER_LIMIT, const int UPPER_LIMIT) {
	do {
		cin >> turns;
	} while (turns < 1 || turns > 30);
}
//function that validates the input for coordinates
void validateCoordinates(int& x,const int  LOWER_LIMIT,const int UPPER_LIMIT) {
	do {
		cin >> x;
	} while (x <= 0 || x > 200);
}
//function that checks wheter the given square can be reached in k turns
bool checkMatrix(int matrix[][10],int p1,int q1) {
	if (matrix[p1][q1] >= 1)
		return true;
	else 
		return false;
}
//recursion that helps us mark whether the square can be reached after exactly k turns
void PossibleDestination(int matrix[][10], int m, int n, int p1, int q1, int counter) {
	if (  p1 < 0 || q1 < 0 || p1 >= n || q1 >= m || counter < 0) {
		return;
	}

		matrix[p1][q1] = 1;
		PossibleDestination(matrix, m, n, p1 - 2, q1 - 1, counter - 1);
		PossibleDestination(matrix, m, n, p1 - 2, q1 + 1, counter - 1);
		PossibleDestination(matrix, m, n, p1 + 2, q1 + 1, counter - 1);
		PossibleDestination(matrix, m, n, p1 + 2, q1 - 1, counter - 1);
		PossibleDestination(matrix, m, n, p1 - 1, q1 - 2, counter - 1);
		PossibleDestination(matrix, m, n, p1 + 1, q1 - 2, counter - 1);
		PossibleDestination(matrix, m, n, p1 - 1, q1 + 2, counter - 1);
		PossibleDestination(matrix, m, n, p1 + 1, q1 + 2, counter - 1);
}
int main() {
	const int TABLE_DIMENSION_LOWER_LIMIT = 3;
	const int TABLE_DIMENSION_UPPER_LIMIT = 200;
	const int COORDINATES_LOWER_LIMIT = 0;
	const int COORDINATES_UPPER_LIMIT = 200;
	const int TURNS_LOWER_LIMIT = 0;
	const int TURNS_UPPER_LIMIT = 30;
	int n = 0, m = 0;
	int p = 0, q = 0;
	int p1 = 0, q1 = 0;
	int k = 0;
	int matrix[10][10] = {0};
	validateTableDimensions(n,TABLE_DIMENSION_LOWER_LIMIT,TABLE_DIMENSION_UPPER_LIMIT);
	validateTableDimensions(m, TABLE_DIMENSION_LOWER_LIMIT, TABLE_DIMENSION_UPPER_LIMIT);
	validateCoordinates(p, COORDINATES_LOWER_LIMIT, COORDINATES_UPPER_LIMIT);
	validateCoordinates(q, COORDINATES_LOWER_LIMIT, COORDINATES_UPPER_LIMIT);
	validateCoordinates(p1, COORDINATES_LOWER_LIMIT, COORDINATES_UPPER_LIMIT);
	validateCoordinates(q1, COORDINATES_LOWER_LIMIT, COORDINATES_UPPER_LIMIT);
	validateTurns(k,TURNS_LOWER_LIMIT,TURNS_UPPER_LIMIT); 
	PossibleDestination(matrix, m, n, p, q,k);
	cout << boolalpha << checkMatrix(matrix, p1, q1)<<endl;
	for (int i = 0;i < n;i++) {
		for (int j = 0;j < m;j++) {
			cout << matrix[i][j]<<" ";
		}
		cout << endl;
	}

	
	
	return 0;
}