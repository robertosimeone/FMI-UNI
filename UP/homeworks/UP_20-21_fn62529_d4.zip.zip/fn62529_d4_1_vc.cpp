/**
*
* Solution to homework assignment 4
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 1
* @compiler VC
*
*/

#include <iostream>
using namespace std;
//function that  returns the maximum of 2 numbers
int maxValue(int a, int b) {
	if (a >= b) {
		return a;
	}
	else
		return b;	
}
//function that finds whether with maximum k changes the sequence will be increasing
//in order to do this in all cases we have to find the max increasing subsequence in the current sequence
//then the numbers that dont belong to this sequence are the numbers that we have to change
bool isIncreasing(int arr[], const int size, int changesLimit) {
	int* maxSubsequenceLenght = new int[size];
	int maxRow = 1;
	maxSubsequenceLenght[0] = 1;
	int currentMaxRow = 0;
	int currentMaxEl = 0;	
	for (int i = 1;i < size;i++) {
		currentMaxRow = 0;
		for (int j = 0;j < i;j++) {
			if (arr[i] >= arr[j]) {
				currentMaxRow = maxValue(currentMaxRow, maxSubsequenceLenght[j]);
			}
		}

		maxSubsequenceLenght[i] = currentMaxRow + 1;
		maxRow = maxValue(maxRow, maxSubsequenceLenght[i]);

	}
	//we have to delete the dynamic array in which we stores the max subsequence lenght to the ith element
	delete[]maxSubsequenceLenght;
	int changesNeeded = size -  maxRow;
	if (changesNeeded <= changesLimit) {
		return true;
	}
	else
		return false;
}

int main(){
	int changesLimit = 0, size = 0;
	cin >> changesLimit >> size;
	//creating a dynamic array because we dont know how many numbers the user is gonna input
	int* arr = new int[size];
		for (int i = 0;i < size;i++) {
		cin >> arr[i];
	}
	cout << isIncreasing(arr, size, changesLimit);
	//deleting the dynamic array in order to prevent memory leaks
	delete[] arr;
	return 0;
} 