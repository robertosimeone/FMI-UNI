/**
*
* Solution to homework assignment 4
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 3
* @compiler VC
*
*/
#include <iostream>
using namespace std;
//function that gets the absolute value of a number
int absolute(int a) {
	if (a >= 0)
		return a;
	else
		return -a;
}
//function that simplifies 2 numbers
//we get the absolute value of the number because we want to handle negative numbers
void simplify(int arr[], const int MAX_SIZE) {
	for (int i = 2;i <= absolute(arr[0]);) {
		if (arr[0] % i == 0 && arr[1] % i == 0) {
			arr[0] /= i;
			arr[1] /= i;
		}
		else {
			i++;
		}
	}

}
//function that returns the result from the operation
int* getMatrix(int numerator, int denominator, int numerator2, int denominator2, char operation,const int MAX_SIZE) {
	//creating a dynamic array
	int* arr = new int[2]; 
	//case if the operation is *
	//then we just multiply both numerators and both dominators and simplify them
	if (operation == '*') {
		arr[0] = numerator * numerator2;
		arr[1] = denominator * denominator2;
		simplify(arr, MAX_SIZE);
		return arr;
	}
	//case if the operatioon is divide
	//then we have to calculate the multiplication of the opposite fraction
	if (operation == '/') {
		arr[0] = numerator * denominator2;
		arr[1] = denominator * numerator2;
		simplify(arr, MAX_SIZE);
		return arr;
	}
	//case if the operation is +
	//then the dominator of the new fraction is the multiplication of the 2 seperate ones
	//and the nominator is the nominator times the dominator of the other fraction + nominator of the opposite fraction times
	//the denominator of the current fraction since we are expanding them
	if (operation == '+') {
		arr[0] = numerator*denominator2 +  denominator*numerator2;
		arr[1] = denominator * denominator2;
		simplify(arr, MAX_SIZE);
		return arr;
	}
	//case if the operation is -
	//its analogical to the previous case with '+'
	if (operation == '-') {
		arr[0] = numerator * denominator2 - denominator * numerator2;
		arr[1] = denominator * denominator2;
		if (arr[0] == 0) {
			arr[1] = 1;
		}
		simplify(arr, MAX_SIZE);
		return arr;
	}
}
int main() {
	const int MAX_SIZE = 2;
	const int UPPER_LIMIT = 100000000;
	const int LOWER_LIMIT = -100000000;
	int numerator = 0,numerator2 = 0;
	int denominator = 0,denominator2 = 0;
	do {
		cin >> numerator;
	} while (numerator<LOWER_LIMIT || numerator>UPPER_LIMIT);
	do {
		cin >> denominator;
	} while (denominator<LOWER_LIMIT || denominator>UPPER_LIMIT);
	char operation = 0;
	cin >> operation;
	do {
		cin >> numerator2;
	} while (numerator2<LOWER_LIMIT || numerator2>UPPER_LIMIT);
	do {
		cin >> denominator2;
	} while (denominator2<LOWER_LIMIT || denominator2>UPPER_LIMIT);
	int* arr = getMatrix(numerator, denominator, numerator2, denominator2, operation,MAX_SIZE);
	cout << *arr << " " << *(arr + 1) << endl;
	//now we have to delete the created dynamic array in order to prevent memory leaks
	delete[] arr;
	return 0;
}