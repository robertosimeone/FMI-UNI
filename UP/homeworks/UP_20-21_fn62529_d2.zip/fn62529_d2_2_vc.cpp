/**
*
* Solution to homework assignment 2
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 2
* @compiler VC
*
*/

#include <iostream>
#include <vector>
using namespace std;

//function that erases equal elements that are next to each other
void doubleElements(vector <double> &vect) {
	int i = 0;
	do{
		
		if (i < vect.size() - 1) {		// last element that we check should be the penultimate one because we dont want to go out of bounds
			if (vect.at(i) == vect.at(i + 1))
				vect.erase(vect.begin() + i);
			else
				i++;
		} else 
			break;

	} while (true);
}
//function that fills the vector with n  numbers 
void fillVector(vector <double>& vect, long long n) {
	double temp = 0;
	for (int i = 0;i < n;i++) {
		do {
			cin >> temp;
		} while (temp < 0.1 || temp > 100);
		vect.push_back(temp);
	}
}//function that validates the input for n
void validate(long long &n) {
	do {
		cin >> n;
	} while (n < 3 || n > 365);
}
int main() {
	double profit = 0;
	long long  n = 0;
	vector <double> stockTable;
	validate(n);
	fillVector(stockTable, n);
	doubleElements(stockTable);
	long long days = stockTable.size(); // days after removing unnecessary days  1 1 2 2 3 1 2 ->  1 2 3 1 2

	if (days != 1) {
		if (stockTable.at(0) < stockTable.at(1)) {	//case for the beginning of the vector
			profit -= stockTable.at(0);
		}
	}
	//for cycle that checks whether the number is between 2 larger numbers(thats when we buy),or 2 smaller numbers(thats when we sell)
	
	for (int i = 1;i < days - 1;i++) {
		if (stockTable.at(i - 1) > stockTable.at(i) and stockTable.at(i) < stockTable.at(i + 1)) {
				profit -= stockTable.at(i);
		}
		if (stockTable.at(i - 1) < stockTable.at(i) and stockTable.at(i) > stockTable.at(i + 1)) {
				profit += stockTable.at(i);
		}
	}
	
	if (days != 1) {
		if (stockTable.at(days - 2) < stockTable.at(days - 1)) {	//case for the end of the vector
			profit += stockTable.at(days - 1);
		}
	}
	cout << profit;
	
	return 0;
}