/**
*
* Solution to homework assignment 2
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 3
* @compiler VC
*
*/

#include <iostream>
#include <vector>
using namespace std;

//function that fills the vector with exactly n numbers
void fillVector(vector <long long>& vect, long long n) {
	long long temp = 0;
	for (int i = 0;i < n;i++) {
		do {
			cin >> temp;
		} while (temp < 0 || temp > 9);
		vect.push_back(temp);
	}
}//function that validates the input for n
void validate(long long& n) {
	do {
		cin >> n;
	} while (n < 3 || n > 1000);
}
int main() {
	int polyndromeCount = 0;
	bool isPolyndrome = true;
	long long n = 0;
	vector <long long> sequence;
	validate(n);
	fillVector(sequence, n);
	for (int i = 0;i < n - 2;i++) 
		for (int j = i+2;j < n;j++) { //j = i+2 so we only get the polyndromes that are with length of  3 or bigger
			if (sequence.at(i) == sequence.at(j)) { //finding 2 matching numbers - start and end of the polyndrome
				isPolyndrome = true;
				for (int p = i + 1, n = j - 1;p<n ;p++, n--) { // cycle that checks the other numbers that are inbetween the first matching ones

					if (sequence.at(p) != sequence.at(n)) {		//if one of the combinations doesn't match we set the flag to false and break
						isPolyndrome = false; 
						break;
					}
				}

				if (isPolyndrome == true)
					polyndromeCount++;
			}
		}
	
	if (polyndromeCount != 0)
		cout << polyndromeCount;
	else 
		cout << "-1";

	return 0;
}