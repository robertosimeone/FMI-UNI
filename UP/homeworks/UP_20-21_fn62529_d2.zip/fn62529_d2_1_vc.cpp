/**
*
* Solution to homework assignment 2
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 1
* @compiler VC
*
*/

#include <iostream>
#include <vector>
using namespace std;

//function that returns the absolute value of a number
long long absolute(long long a) {
	if (a < 0)
		return -a;
	else
		return a;
}
//function that fills the vector with n many numbers
void fillVector(vector <long long>& vect, long long n) {
	long long temp = 0;
	for (int i = 0;i < n;i++) {
		do {
			cin >> temp;
		} while (temp < 1);
		vect.push_back(temp);
	}
}
//function that validates the input of n
void validate(long long& n) {
	do {
		cin >> n;
	} while (n < 3 || n > 100);
}

int main() {
	long long n = 0;
	bool isTriangleSequence = true;
	vector <long long> sequence;
	validate(n);
	fillVector(sequence, n);
	//for cycle that checks whether the vector is a triangle sequence
	for (int i = 0;i < n/2;i++) {
		if (absolute(sequence.at(i) - sequence.at(i + 1)) != absolute(sequence.at(n - i - 1) - sequence.at(n - i - 2))) {
			isTriangleSequence = false;
			break;
		}
	}

	if (isTriangleSequence == true)
		cout << true;
	else 
		cout << false;

	return 0;
}