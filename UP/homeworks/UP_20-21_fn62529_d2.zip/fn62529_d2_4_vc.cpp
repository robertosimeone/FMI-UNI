/**
*
* Solution to homework assignment 2
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 4
* @compiler VC
*
*/

#include <iostream>
#include <vector>
using namespace std;

//function that fills the vector with n different  numbers
void fillVector(vector <long long>& vect, long long n) {
	long long  temp = 0;
	bool isUnique = true;
	int uniqueNumbers = 0;
	do {
		do {
			cin >> temp;

		} while (temp < -2147483648 || temp > 2147483648);

		if (vect.size() == 0) {
			vect.push_back(temp);
			uniqueNumbers++;
		}
		else {
			isUnique = true;
			for (int i = 0;i < vect.size();i++) {
				if (temp == vect.at(i)) {
					isUnique = false;
					break;
				}
				
			}
			if (isUnique == true) {
				vect.push_back(temp);
				uniqueNumbers++;
			}
		}
	} while (uniqueNumbers < n);

}

//functions that validates the input for n
void validate(long long& n) {

	do {
		cin >> n;
	} while (n < 3 || n > 100);
}
int main() {

	int sumsZero = 0;
	long long n = 0;
	vector <long long> sequence;
	validate(n);
	fillVector(sequence, n);

	//for-cycles that find each sum of 3 numbers that is equal to zero
	for(int i = 0;i<=n-3;i++)
		for(int j = i+1;j<=n-2;j++)
			for(int k = j+1;k<=n-1;k++)
				if (sequence.at(i) + sequence.at(j) + sequence.at(k) == 0) {
					sumsZero++;
				}

	cout << sumsZero;

	return 0;
}