/**
*
* Solution to homework assignment 3
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 1
* @compiler vc
*
*/
#include <iostream>
using namespace std;
void swap(int& a, int& b)
{
	int c = 0;
	c = a;
	a = b;
	b = c;
}
//function that calculates the size of the array
int arraySize(char  arr[]) {
	int size = 0;
	for (int i = 0;arr[i] != 0;i++) {
		size++;
	}
	return size;
}
//function that determines whether a char array is true or not
bool isTrue(char arr[], const int size) {
	const int MAX_SIZE = 150;
	bool flag = false;
	//if size is equal to one then the array is always true
	if (size == 1)
		return true;
	int lettersCount[MAX_SIZE] = { 0 };
	int counter = 0;
	char checked[MAX_SIZE];
	//checking whether we've already counted how many times we've encountered the letter
	for (int i = 0;arr[i] != 0;i++) {
		flag = false;
		for (int k = 0;k<counter;k++) {
			if (checked[k] == arr[i]) {
				flag = true;
				break;
			}
		}
		//if we havent encountered the letter yet
		//we put it in the checked array and start counting how many times we are going to encounter it
		if (flag == false) {
			++lettersCount[counter];
			checked[counter] = arr[i];
			for (int j = i + 1;arr[j] != 0;j++) {
				if (arr[i] == arr[j]) {
					lettersCount[counter]++;
				}
			}
			counter++;

		}
	}
	//finding the index of the max element in the array
	int maxEl = 0;
	for (int i = 1;i < counter;i++) {
		if (lettersCount[i] > lettersCount[maxEl])
			maxEl = i;
	}
	//if the index is different than 0, meaning if the maxel isnt in place already we swap it 
	if (maxEl != 0) {
		lettersCount[maxEl] += lettersCount[0];
		lettersCount[0] = lettersCount[maxEl] - lettersCount[0];
		lettersCount[maxEl] = lettersCount[maxEl] - lettersCount[0];
	}
	int minEl = 0;
	for (int i = 1;i < counter;i++) {
		if (lettersCount[i] < lettersCount[minEl])
			minEl = i;
	}
	//same goes for the min element,in case every letters has occured lets say n times and one letter has occured only 1 time
	//if the index is different than counter -1 then we swap it
	if (minEl != counter-1) {
		swap(lettersCount[counter-1], lettersCount[minEl]);
	}
	//tribetire ->all of the symbols occur 2 times except b
		if (lettersCount[counter-1] == 1) {
		for (int i = counter;i > 0;i--) {
			if (lettersCount[i] != lettersCount[i - 1] and (lettersCount[i - 1] != 1 and lettersCount[i] != 1))
				return false;
		}
		return true;
	}

	//if the first element(max) is equal to the second one +1 or they are equal then we can check the other ones
	if (lettersCount[0] == (lettersCount[1] + 1) || lettersCount[0] == lettersCount[1]) {
		for (int i = 1;i < counter-1 ;i++) {
			//even if one of them is different that means that the array is not true and we return false
			if (lettersCount[i] != lettersCount[i + 1])
				return false;
		}
		return true;
	}
	else
		return false;
}
int main() {
	const int MAX_SIZE = 151;
	char arr[MAX_SIZE];
	cin >> arr;
	int size = arraySize(arr);
	cout << isTrue(arr, size);
	return 0;
}