/**
*
* Solution to homework assignment 3
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 5
* @compiler vc
*
*/
#include <iostream>
using namespace std;
#include <fstream>
//function that checks whether the given array has only letters
bool isValid(char arr[]) {
	bool flag = true;
	for (int i = 0;arr[i] != 0;i++) {
		if ((arr[i] >= 65 && arr[i] <= 90) || (arr[i] <= 122 && arr[i] >= 97)) {
			flag = true;
		}
		else {
			flag = false;
			break;
		}
	}
	return flag;
}
//calculating the size of a given char array
int mystrlen(char arr[]) {
	int size = 0;
	for (int i = 0;arr[i] != 0;i++) {
		size++;
	}

	return size;
}
//swapping elements
void swap(char &a, char &b) {
	char c;
	c = a;
	a = b;
	b = c;
}
void decypher(char cypher[]) {
	bool flag = true;
	char  element = 0;
	char min = 0;
	ifstream file;
	file.open("message.txt");
	if (file.is_open()) {//checking if the file can open,if not we return -2
		while (file >> cypher) {
			//if there are elements that are not letter in our array we return -1
			if (isValid(cypher)) {
				int size = mystrlen(cypher);//calculating the size of each given char array
				//for cycle that orders the elements in each char array from smallest(ASCII code) to biggest
				for (int i = 0;cypher[i + 1] != 0;i++) {
					min = i;
					for (int j = i + 1;cypher[j] != 0;j++) {
						if (cypher[min] > cypher[j]) {
							min = j;
						}
					}
					swap(cypher[i], cypher[min]);
				}
				//for cycle that checks if there is a gap between the letter with the smalelst ASCII code and the next one
				//if there is a gap that means that that letter is missing in our array and therefore its the letter with
				//the smallest ASCII code that is bigger than smallest and  is missing from the array
				for (int i = 0;cypher[i + 1] != 0;i++) {
					//since there is a gap between big letters and small letters we have to set the transition manually
					if (cypher[i] == 'Z') {
						element = 'a';
					}
					else {
						element = cypher[i] + 1;
					}
					flag = true;
					//searching for the element in the array
					//if we cannot find it that means there is a gap and this is the element that we need
					for (int j = i + 1;cypher[j] != 0;j++) {
						if (element == cypher[j]) {
							flag = false;
							break;
						}
					}
					//if the given element is not found we print it and break
					if (flag == true) {
						cout << element;
						break;
					}
				}
				//since the array doesnt cover the case where the letter with the smallest ascii code 
				//that isnt in the array is the last one(Example:abcd,we need e) we do it at the end
				//if the array consisted of all the big letters and all the small ones we print '.'
				//same goes for the case: xyz
				//if element is 'Z', we print a
				//in every other case we print the letter with the next ASCII code
				if ((cypher[size - 1] == element) && (element != 'z')) {
					if (element == 'Z') {
						element = 'a';
						cout << element;
					}
					else {
						element += 1;
						cout << element;
					}
				}
				else if ((cypher[size - 1] == element) && (element == 'z'))
				{
					cout << '.';
				}
			}
			else {
				cout << "-1";
				break;
			}
		}
	}
	else {
		cout << "-2";
	}
	//closing the file
	file.close();
}

 
int main(){

	const int MAX_SIZE = 151;
	char cypher[MAX_SIZE];
	decypher(cypher);
	return 0;
}