/**
*
* Solution to homework assignment 3
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 2
* @compiler vc
*
*/
#include <iostream>
using namespace std;
//function that checks whether all of the elements of the array are letters
bool isValid(char firstArray[],const int LOWER_LIMIT,const int UPPER_LIMIT) {
	bool flag = true;
	for (int i = 0;firstArray[i] != '\0';i++) {
		if (firstArray[i] > UPPER_LIMIT || firstArray[i] < LOWER_LIMIT) {
			flag = false;
			break;
		}
	}
		if (flag)
			return true;
		else 
			return false;

}
//function that checks whether the 3rd array is equal to the first one + second one
//since we know all of them are going to be letters,instead of deleting the letters, we can just change them to a number
//for example 0
bool isEqual(char firstArray[], char secondArray[], char thirdArray[],int first,int second, int third) {
	bool flag = true;
	//for cycle that checks whether a letter from the first array is equal to a letter from the third array
	//if so we just set them both to 0
	for (int i = 0;i < first;i++) {
		for (int j = 0;j < third;j++)
		{
			if (firstArray[i] == thirdArray[j]) {
				firstArray[i] = '0';
				thirdArray[j] = '0';
				break;
			}
		}
	}
	//for cycle that checks whether a letter from the second array is equal to a letter from the third array
	//if so we just set them both to 0
	for (int i = 0;i < second;i++) {
		for (int j = 0;j < third;j++)
		{
			if (secondArray[i] == thirdArray[j]) {
				secondArray[i] = '0';
				thirdArray[j] = '0';
				break;
			}
		}
	}
	//if a letter from the first array isnt 0, that means we havent found a matching letter from the third array and we return false
	for (int j = 0;firstArray[j] != '\0';j++) {
		if (firstArray[j] != '0') {
			flag = false;
			break;
		}
	}
	//if a letter from the second array isnt 0, that means we havent found a matching letter from the third array and we return false
	for (int i = 0;secondArray[i] != '\0';i++) {
		if (secondArray[i] != '0') {
			flag = false;
			break;
		}
	}
	//if a letter from third array isnt 0 that means that we havent found a matching letter from the first two or 
	//the size of the third array is bigger than the size of the first array + size of the second array
	for (int i = 0;thirdArray[i] != '\0';i++) {
				if (thirdArray[i] != '0') {
					flag = false;
					break;
				}
			}
			if (flag)
				return true;
			else return false;
		}


int main() {
	const int LOWER_LIMIT = 97;
	const int UPPER_LIMIT = 122;
	const int MAX_ELEMENTS = 151;
	char firstWord[MAX_ELEMENTS];
	char secondWord[MAX_ELEMENTS];
	char thirdWord[MAX_ELEMENTS];
	cin >> firstWord >> secondWord >> thirdWord;
	int size1 = strlen(firstWord);
	int size2 = strlen(secondWord);
	int size3 = strlen(thirdWord);
	if (isValid(firstWord,LOWER_LIMIT,UPPER_LIMIT)  and isValid(secondWord,LOWER_LIMIT, UPPER_LIMIT)  and isValid(thirdWord,LOWER_LIMIT, UPPER_LIMIT) )
		cout << isEqual(firstWord, secondWord, thirdWord, size1, size2, size3);
	else
		cout << "-1";
	
	return 0;
}