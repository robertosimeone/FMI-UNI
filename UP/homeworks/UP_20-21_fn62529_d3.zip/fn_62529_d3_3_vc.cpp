/**
*
* Solution to homework assignment 3
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 3
* @compiler vc
*
*/
#include <iostream>
using namespace std;
const int MAX_SIZE = 1000;
double square[MAX_SIZE][MAX_SIZE];
//function that multiplies the number b times
double myPow(double a, int b) {
	double result = 1.0;
	if (b >= 0) {
		for (int i = 0;i < b ;i++)
			result *= a;

	}
	else  {
		b = -b;
		for (int i = 0;i < b;i++)
			result /= a;

	}
	return result;
	
}
//we need a const because we cannot compare double numbers that accurately
const double DIFF = myPow(10, -9);
//function that returns absolute value
double myAbs(double a) {
	if (a >= 0)
		return a;
	else
		return -a;
}

//function that validates the input for every number in the matrix
void validateSquare(double square[][1000], int n, const int LOWER_LIMIT, const int UPPER_LIMIT) {
	double temp = 0.0;
	for (int i = 0;i < n;i++)
		for (int j = 0;j < n;j++) {
				do {
					cin >> square[i][j];
				} while (temp < LOWER_LIMIT || temp > UPPER_LIMIT);
		}
}
//function that compares 2 numbers using a constant
//since double numbers are not accurate after a given point
//we compare the absolute value of their difference with a number(that number plays a role of a mistake)
bool isEqual(double a, double b) {
	if (myAbs(a-b) < DIFF)
		return true;
	else 
		return false;
}
//function that returns whether the given matrix is a magic square
bool isMagicSquare(double square[][1000], int n) {
	//we need 2 variables to compare the sum of the 2 diagonals
	double firstSum = 0;
	double secondSum = 0;
	for (int i = 0;i < n;i++) {
		firstSum += square[i][i];
	}
	for (int i = 0, j = n - 1;i < n;i++, j--) {
		secondSum += square[i][j];
	}
	//we need 1 more variable to compare the other 2 sums of the rows and columns
	int compareToSum = secondSum;
	// if the sums of the 2 diagonals don't match , then we return false
	if (!isEqual(firstSum,secondSum))
		return false;
	//we chech the sums of the rolls and the columns at the same time - 1row and 1 col and so on
	for (int i = 0;i < n;i++) {
		firstSum = 0;
		secondSum = 0;
		for (int j = 0;j < n;j++) {
			secondSum += square[i][j];
			firstSum += square[j][i];

		}
		//sum and sum2 have to be equal and in the same time equal to sum3 in order to continue,if not we return false
		if (!isEqual(firstSum, secondSum) || !isEqual(compareToSum, firstSum)) {
			return false;
		}
		
	}//if we got to here that means that the 2 sums are equal then we just have to check with the third one
	if (isEqual(firstSum, compareToSum)) {
		return true;
	}
}
int main() {
	const int LOWER_LIMIT = 1;
	const int UPPER_LIMIT = 1000;
	const int LOWER_LIMIT_ARRAY = 0;
	const int UPPER_LIMIT_ARRAY = 100;
	int n = 0;
		do {
			cin >> n;
		} while (n <= LOWER_LIMIT || n >= UPPER_LIMIT);
	
		validateSquare(square, n,LOWER_LIMIT_ARRAY,UPPER_LIMIT_ARRAY);
		cout <<boolalpha<< isMagicSquare(square, n);

		return 0;
	
	}
