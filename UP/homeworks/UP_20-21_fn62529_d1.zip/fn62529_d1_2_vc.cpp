/**
*
* Solution to homework assignment 1
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020 / 2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 2
* @compiler VC
*/

#include <iostream>
using namespace std;
int main() {

	int numberEntered = 0, secondBiggest = 0, firstBiggest = 0, counter = 0;

	do {
		cin >> numberEntered;
		if (numberEntered > firstBiggest) {
			secondBiggest = firstBiggest;
			firstBiggest = numberEntered;
			counter++;
		}
		else if (numberEntered < firstBiggest && numberEntered > secondBiggest){
			secondBiggest = numberEntered;
			counter++;

		}
	} while (numberEntered > 0);

	if (counter <= 1) {	// checking whether the user has entered less than 2 different numbers
		cout << "-1";
	}
	else {
		cout << secondBiggest;
	}
	return 0;
}