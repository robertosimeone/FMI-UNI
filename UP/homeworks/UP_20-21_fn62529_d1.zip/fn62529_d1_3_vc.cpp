/**
*
* Solution to homework assignment 1
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020 / 2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 3
* @compiler VC
*/
#include <iostream>
using namespace std;
//function that orders the numbers from smallest to biggest
void numbersOrdered(int& a, int& b, int& c) {
	int d = 0;
	if (a > b) {
		d = a;
		a = b;
		b = d;
	}
	if (a > c) {
		d = a;
		a = c;
		c = d;
	}
	if (b > c) {
		d = b;
		b = c;
		c = d;
	}
}
int main() {

	const int lowerLimit = 0;
	const int upperLimit = 9;
	int firstDigit = 0, secondDigit = 0, thirdDigit = 0;
	//3 do-while loops in order to validate the numbers
	do {
		cin >> firstDigit;
	} while (firstDigit < lowerLimit || firstDigit > upperLimit);

	do {
		cin >> secondDigit;
	} while (secondDigit < lowerLimit || secondDigit > upperLimit);

	do {
		cin >> thirdDigit;
	} while (thirdDigit < lowerLimit || thirdDigit > upperLimit);

	
	numbersOrdered(firstDigit, secondDigit, thirdDigit);
	//going through all the possible cases
	if (firstDigit == 0 and secondDigit == 0 and thirdDigit == 0)	// 0 0 0
		cout << 0;
	else if (secondDigit == 0 and firstDigit == 0 and thirdDigit != 0) {	// 0 0 x

		cout << thirdDigit * 1000 + thirdDigit;
	}

	else if (firstDigit == 0 and secondDigit != thirdDigit) {	// 0 x y

		cout << secondDigit * 10000 + thirdDigit * 100 + secondDigit;
	}

	else if (firstDigit == 0 and secondDigit == thirdDigit) {	//0 x x

		cout << secondDigit * 100 + secondDigit;
	}

	else if (firstDigit != secondDigit and firstDigit != thirdDigit and secondDigit != thirdDigit) {	// x y z

		cout << firstDigit * 10000 + secondDigit * 1000 + thirdDigit * 100 + secondDigit * 10 + firstDigit;
	}

	else if (firstDigit == secondDigit and firstDigit == thirdDigit) {	// x x x

		cout << firstDigit * 100 + firstDigit * 10 + firstDigit;
	}

	else if (firstDigit != secondDigit and secondDigit == thirdDigit) { // 1 2 2

		cout << thirdDigit * 100 + firstDigit * 10 + thirdDigit;
	}

	else 
		cout << firstDigit * 100 + thirdDigit * 10 + firstDigit; // 1 1 2

	return 0;
}