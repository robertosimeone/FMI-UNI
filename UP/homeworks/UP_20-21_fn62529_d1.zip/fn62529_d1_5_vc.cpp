/**
*
* Solution to homework assignment 1
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020 / 2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 5
* @compiler VC
*/
#include <iostream>
#include <cmath>
using namespace std;
int main() {

	const int lowerLimit = 2;
	const int upperLimit = pow(10, 9);
	int decimalPlaces = 0, denominator = 0;
	double fraction = 0;
	bool infFraction = false;

	do {
		cin >> denominator;
	} while (denominator < lowerLimit || denominator > upperLimit);

	fraction = 1.00 / denominator;

	//do-while loop that finds whether the number is dividable by 2 and 5
	do {

		if (denominator % 2 == 0) {
			denominator /= 2;

		}

		else if (denominator % 5 == 0) {
			denominator /= 5;

		}
		else {
			infFraction = true;
			break;
		}

	} while (denominator != 1);

	// do-while loop that finds how many decimal places the given number has
	do
	{
		fraction *= 10;
		decimalPlaces++;

	} while (fraction != (int)fraction);

	if (infFraction == false) {
		cout << decimalPlaces;
	}

	else {
		cout << "NO";
	}

	return 0;
}