/**
*
* Solution to homework assignment 1
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020 / 2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 4
* @compiler VC
*/
#include <iostream>
#include <cmath>;
using namespace std;
//function that  orders 3 numbers from smallest to biggest
void  numbersOrdered(int &a, int &b, int &c) {
	int x = 0;
		if (a > b) {
			x = a;
			a = b;
			b = x;
		}

		if (a > c) {
			x = a;
			a = c;
			c = x;
		}

		if (b > c) {
			x = b;
			b = c;
			c = x;
		}
}
//function that multiplies the 2 smallest numbers
void smallestMultiplied(int &a, int &b, int &c, int &d) {
	if (a * b <= a * d) {
		a = a * b;
		b = d;
	}
	else
		a = a * d;
}

int main() {
	const int lowerLimit = 1;
	const int upperLimit = pow(10, 9);
	int n = 0;
	int divider = 2;
	int firstMiltiplier = 1, secondMultiplier = 1, thirdMultiplier = 1;
	// do-while loop in order to validate the number
	do {
		cin >> n;
	} while (n < lowerLimit || n > upperLimit);

	if (n == 1)
		cout << firstMiltiplier << " " << secondMultiplier << " " << thirdMultiplier;
	else if (n == 0) {
		cout << 0 << " " << 0 << " " << 0;
	}
	else {
		//while loop that goes through all the dividers of a num
		while (n != 1) {
			if (n % divider == 0) {
				numbersOrdered(firstMiltiplier, secondMultiplier, thirdMultiplier);
				smallestMultiplied(firstMiltiplier, secondMultiplier, thirdMultiplier, divider);//multiplying the 2 smallest numbers
				n /= divider;
			}
			else
				divider++;
		}
		numbersOrdered(firstMiltiplier, secondMultiplier, thirdMultiplier);
		cout << firstMiltiplier << " " << secondMultiplier << " " << thirdMultiplier;
	}
	return 0;
}	