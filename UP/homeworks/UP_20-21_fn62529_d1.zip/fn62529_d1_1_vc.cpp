/**
*
* Solution to homework assignment 1
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020 / 2021
*
* @author Robert Borisov
* @idnumber 62529
* @task 1
* @compiler VC
*/
#include <iostream>
using namespace std;

int main() {

    int toyPrice = 0, birthdayCount = 0, moneyNeeded = 0;
    const int treatMoney = 5;
    int birthdayMoney = 30 - treatMoney;
    int moneyAccumulated = 0;

    do {
        cin >> birthdayCount;
    } while (birthdayCount <= 0);

    do {
        cin >> moneyNeeded;
    } while (moneyNeeded <= 0);

    do {
        cin >> toyPrice;
    } while (toyPrice <= 0);

    for (int i = 1; i <= birthdayCount; i++) {


        if (i % 2 == 1) {
            moneyAccumulated += toyPrice;
        }
        else {
            moneyAccumulated += birthdayMoney;
            birthdayMoney += 30;
        }
    }

    if (moneyAccumulated >= moneyNeeded) {

        cout << "yes" << endl;
        cout << moneyAccumulated - moneyNeeded << endl;


    }
    else {

        cout << "no" << endl;
        cout << moneyNeeded - moneyAccumulated << endl;
    }
    return 0;
}