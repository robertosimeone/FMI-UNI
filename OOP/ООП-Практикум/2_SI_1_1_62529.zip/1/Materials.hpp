/**
* Solution to homework assignment 2
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author <Robert Borisov> m
* @idnumber <62529>
* @task <1>
* @compiler <VC>*/
#pragma once
#include <vector>
#include <utility>
using namespace std;
enum class materialType {
	herb,
	cloth,
	ores,
	essence,
};
class Materials {
	vector<pair<materialType, unsigned int>> materials;


public:
	Materials();
	void copyOtherVector(vector<pair<materialType, unsigned int>>&);
	bool isEmpty() const;
	void arrangeMaterials();
	bool hasMatchingType(materialType) const;
	size_t slotsTaken() const;
	void addMaterial(pair<materialType, unsigned int>);
	size_t sumOfElementType(materialType) const ;
	void removeMaterialByIndex(size_t);
	void removeMaterial(Materials&);
	void clear();
	vector<pair<materialType, unsigned int>> getmaterials()const;
	pair<materialType,unsigned int > getPairAtIndex(size_t) const;
	size_t getSize() const ;
};