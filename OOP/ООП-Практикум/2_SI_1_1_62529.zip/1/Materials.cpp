/**
* Solution to homework assignment 2
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author <Robert Borisov> m
* @idnumber <62529>
* @task <1>
* @compiler <VC>*/
#pragma once
#include "Materials.hpp"
using namespace std;
#include <utility>
#include <iostream>
Materials::Materials() {

}
void Materials::copyOtherVector(vector<pair<materialType, unsigned int>>& toCopy) {
	this->materials = toCopy;
}
bool Materials::isEmpty() const {
	if (materials.size() == 0)
		return true;
	return false;
}
bool Materials::hasMatchingType(materialType type) const {
	for (size_t i = 0;i < materials.size();++i) {
		if (materials[i].first == type)
			return true;
	}
	return false;
}
void Materials::addMaterial(pair<materialType, unsigned int>material) {
	materials.push_back(material);
}
void Materials::removeMaterialByIndex(size_t index) {
	if (index >= materials.size())
		cout << "Index is out of bounds" << endl;
	else {
		materials.erase(materials.begin() + index);
		cout << "You have successfully removed item with index: " << index << endl;
	}
}
size_t Materials::slotsTaken() const {
	return materials.size();
}
void Materials::arrangeMaterials() {
	size_t slot_space = -1;
	materialType type;
	materialType essence = materialType::essence;
	materialType herb = materialType::herb;
	materialType cloth = materialType::cloth;
	materialType ores = materialType::ores;
	size_t sum_essence = this->sumOfElementType(essence);
	size_t sum_herb = this->sumOfElementType(herb);
	size_t sum_cloth = this->sumOfElementType(cloth);
	size_t sum_ores = this->sumOfElementType(ores);
	vector <pair<materialType, unsigned int>> arrangedMaterials;
	vector <size_t> materialsToAdd;
	materialsToAdd.push_back(sum_essence);
	materialsToAdd.push_back(sum_herb);
	materialsToAdd.push_back(sum_cloth);
	materialsToAdd.push_back(sum_ores);
	for (int i = 0; i < 4;i++) {
		if (i == 0) {
			type = materialType::essence;
			slot_space = 10;
		}
		else if (i == 1) {
			type = materialType::herb;
			slot_space = 20;
		}
		else if (i == 2) {
			type = materialType::cloth;
			slot_space = 20;
		}
		else {
			type = materialType::ores;
			slot_space = 20;
		}
		while (materialsToAdd[i] != 0) {
			if (materialsToAdd[i] - slot_space >= 0) {
				materialsToAdd[i] -= slot_space;
				pair <materialType, unsigned int> toAdd;
				toAdd.first = type;
				toAdd.second = slot_space;
				arrangedMaterials.push_back(toAdd);
			}
			else {
				materialsToAdd[i] = 0;
				pair <materialType, unsigned int> toAdd;
				toAdd.first = type;
				toAdd.second = materialsToAdd[i];
				arrangedMaterials.push_back(toAdd);
			}
		}
	}
	this->materials = arrangedMaterials;

}
size_t Materials::sumOfElementType(materialType type) const { 
	size_t sum = 0;
	for (size_t i = 0;i < materials.size();++i) {
		if (materials[i].first == type) {
			sum += materials[i].second;
		}
	}
	return sum;

}
void Materials::clear() {
	while (materials.size() != 0) {
		materials.pop_back();
	}
}
pair<materialType, unsigned int > Materials::getPairAtIndex(size_t index) const  {
	return materials[index];
}
size_t Materials::getSize() const {
	return materials.size();
}
void Materials::removeMaterial(Materials& toRemove) {
	bool isCorrect = true;
	materialType essence = materialType::essence;
	materialType herb = materialType::herb;
	materialType cloth = materialType::cloth;
	materialType ores = materialType::ores;
	size_t sum_essence = this->sumOfElementType(essence)-toRemove.sumOfElementType(essence);
	size_t sum_herb = this->sumOfElementType(herb) - toRemove.sumOfElementType(herb);
	size_t sum_cloth = this->sumOfElementType(cloth) - toRemove.sumOfElementType(cloth);
	size_t sum_ores = this->sumOfElementType(ores) - toRemove.sumOfElementType(ores);
	if (sum_essence < 0 || sum_herb < 0 || sum_cloth < 0 || sum_ores < 0) {
		cout << "Oops.Looks like you've tried to remove too many elements" << endl;
		return;
	}

	vector<pair<materialType, unsigned int>> newMaterials;
	pair<materialType, unsigned int > essence1;
	essence1.first = essence;
	essence1.second = sum_essence;
	newMaterials.push_back(essence1);

	pair<materialType, unsigned int > herb1;
	herb1.first = herb;
	herb1.second = sum_herb;
	newMaterials.push_back(herb1);

	pair<materialType, unsigned int > cloth1;
	cloth1.first = cloth;
	cloth1.second = sum_cloth;
	newMaterials.push_back(cloth1);

	pair<materialType, unsigned int > ores1;
	ores1.first = ores;
	ores1.second = sum_ores;
	newMaterials.push_back(ores1);
	this->copyOtherVector(newMaterials);
	this->arrangeMaterials();
	
}
vector<pair<materialType, unsigned int>> Materials::getmaterials() const {
	return materials;
}
