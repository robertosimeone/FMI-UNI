/**
* Solution to homework assignment 2
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author <Robert Borisov> m
* @idnumber <62529>
* @task <1>
* @compiler <VC>*/
#pragma once
#include <utility>
#include <string>
#include <vector>
using namespace std;
enum class ArmorType {
	cloth,
	leather,
	mail,
};
class Armor {
private:
	ArmorType type;
	long defense;
	vector <pair <string, unsigned int>> effects;
public:
	Armor();
	Armor(ArmorType, long);
	long gearScore() const;
	Armor(const Armor&);
	Armor& operator=(const Armor&);
	void addEffect(pair <string, unsigned int> effect);
	void changeEffectPower(string, unsigned int);
	void setDefense(long);
	void setType(ArmorType type);
	void removeEffect(string);
	void changeArmorType(ArmorType);
	string getArmor() const;
	long getDefense() const;
	vector <pair <string, unsigned int>> getEffects() const;
	//implement creating static methods armor
	





};