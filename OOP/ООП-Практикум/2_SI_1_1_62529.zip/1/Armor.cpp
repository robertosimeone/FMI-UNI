/**
* Solution to homework assignment 2
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author <Robert Borisov> m
* @idnumber <62529>
* @task <1>
* @compiler <VC>*/
#include "Armor.hpp"
#include <iostream>
using namespace std;
#include <string>
Armor::Armor() {
	type = ArmorType::cloth;
	defense = 0;
}
long Armor::gearScore() const {
	long score = 0;
	for (size_t i = 0;i < effects.size();++i) {
		score += effects[i].second;
	}
	return score;
}
Armor::Armor(const Armor& other) {
	this->defense = other.defense;
	this->effects = other.effects;
	this->type = other.type;
}
Armor& Armor::operator=(const Armor& other) {
	this->defense = other.defense;
	this->effects = other.effects;
	this->type = other.type;
	return *this;
}
void Armor::addEffect(pair <string, unsigned int> effect) {
	effects.push_back(effect);
}
void Armor::setDefense(long defense) {
	this->defense = defense;
}
void Armor::setType(ArmorType type) {
	this->type = type;
}
void Armor::changeArmorType(ArmorType type) {
	this->type = type;
}
void Armor::changeEffectPower(string effect, unsigned int power) {
	bool isFound = false;
	for (size_t i = 0;i < effects.size();++i) {
		if (effects[i].first == effect) {
			effects[i].second = power;
			cout << "Power of armor: " << effect << "has been changed successfully" << endl;
			isFound = true;
			break;
		}
	}
	if (!isFound)
		cout << "No armor with such name!" << endl;
}
void Armor::removeEffect(string effect) {
	bool isFound = false;
	for (size_t i = 0;i < effects.size();++i) {
		if (effects[i].first == effect) {
			effects.erase(effects.begin() + i);
			cout << "You have successfully removed an item with name : " << effect << endl;
			isFound = true;
			break;
		}
	}
	if (!isFound)
		cout << "No effect with such name!" << endl;
}
Armor::Armor(ArmorType type, long defense) {
	this->type = type;
	this->defense = defense;
}
string Armor::getArmor() const  {
	string armortype;
	if (type == ArmorType::cloth)
		armortype = "cloth";
	if (type == ArmorType::mail)
		armortype = "mail";
	if (type == ArmorType::leather)
		armortype = "leather";
	return armortype;
}
long Armor::getDefense()const {
	return defense;
}
vector <pair <string, unsigned int>>Armor:: getEffects() const {
	return effects;
}