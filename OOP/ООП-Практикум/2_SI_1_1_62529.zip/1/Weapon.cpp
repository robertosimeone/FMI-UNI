/**
* Solution to homework assignment 2
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author <Robert Borisov> m
* @idnumber <62529>
* @task <1>
* @compiler <VC>*/
#include "Weapon.hpp"
#include <iostream>
using namespace std;
#include <string>
Weapon::Weapon() {
	hit_damage.first = 0;
	hit_damage.second = 0;
	weapon.first == weaponKind::axe;
	weapon.second = weaponType::one_handed;
}
double Weapon:: WeaponScore() const {
	double effectscore = 0;
	double weaponscore = 0;
	double avghitdmg = 0;
	double multiplier = 0;
	if (this->weapon.second == weaponType::one_handed) {
		multiplier = 0.75;
	}
	else {
		multiplier = 1.5;
	}
	avghitdmg = (hit_damage.first + hit_damage.second) / 2;
	for (size_t i = 0;i < effects.size();i++){
		effectscore += effects[i].second * multiplier;
	}
	weaponscore = avghitdmg + effectscore;
	return weaponscore;
}

void Weapon::changeWeaponType(weaponType &type ) {
	this->weapon.second = type;
}
void Weapon::changeWeaponKind(weaponKind& kind) {
	//check how this affects weapontype
	this->weapon.first = kind;
	
	if (kind == weaponKind::dagger) {
		this->weapon.second = weaponType::one_handed;

	}else if (kind == weaponKind::staff) {
		this->weapon.second = weaponType::two_handed;
	}
	
}
void Weapon::addEffect(pair<string, unsigned int>& effect) {
	bool isFound = false;
	for (size_t i = 0;i < effects.size();i++) {
		if (effects[i].first == effect.first) {
			effects[i].second = effect.second;
			isFound = true;
			break;
		}
	}
	if(!isFound)
	this->effects.push_back(effect);
}
void Weapon::changeEffectPower(string name, unsigned int power) {
	bool isFound = false;
	for (size_t i = 0;i < effects.size();i++) {
		if (effects[i].first == name) {
			isFound = true;
			effects[i].second = power;
			break;	
		}
	}
	if (!isFound) {
		cout << "Sorry there is no element with such name." << endl;
	}
}
void Weapon::removeEffect(string name) {
	bool isFound = false;
	for (size_t i = 0;i < effects.size();i++) {
		if (effects[i].first == name) {
			isFound = true;
			effects.erase(effects.begin() + i);
		}
	}
	if (!isFound) {
		cout << "There is no element with such name!" << endl;
	}
}

weaponType Weapon::getWeaponType() const {
	return weapon.second;
}
Weapon::Weapon(const Weapon& other) {
	this->weapon = other.weapon;
	this->hit_damage = other.hit_damage;
	this->effects = other.effects;
}
Weapon& Weapon::operator=(const Weapon& other) {
	this->weapon = other.weapon;
	this->hit_damage = other.hit_damage;
	this->effects = other.effects;
	return *this;
}
void Weapon::setHitDmg(double lowest_value, double highest_value) {
	hit_damage.first = lowest_value;
	hit_damage.second = highest_value;
}
 Weapon Weapon::createAxe() {
	 Weapon axe = Weapon();
	 weaponKind kind = weaponKind::axe;
	 axe.changeWeaponKind(kind);
	 axe.setHitDmg(10, 20);
	 return axe;

}
 Weapon Weapon::createSword() {
	 Weapon sword = Weapon();
	 weaponKind kind = weaponKind::sword;
	 sword.changeWeaponKind(kind);
	 sword.setHitDmg(11, 22);
	 return sword;
 }
 Weapon Weapon::createDagger() {
	 Weapon dagger = Weapon();
	 weaponKind kind = weaponKind::dagger;
	 dagger.changeWeaponKind(kind);
	 dagger.setHitDmg(12, 24);
	 return dagger;
 }
 Weapon Weapon::createMace() {
	 Weapon mace = Weapon();
	 weaponKind kind = weaponKind::mace;
	 mace.changeWeaponKind(kind);
	 mace.setHitDmg(13, 26);
	 return mace;

 }
 Weapon Weapon::createStaff() {
	 Weapon staff = Weapon();
	 weaponKind kind = weaponKind::staff;
	 staff.changeWeaponKind(kind);
	 staff.setHitDmg(14, 28);
	 return staff;
 }
 string Weapon::getweaponkind() const {
	 string kind;
	 if (weapon.first == weaponKind::axe)
		 kind = "axe";
	 if (weapon.first == weaponKind::dagger)
		 kind = "dagger";
	 if (weapon.first == weaponKind::mace)
		 kind = "mace";
	 if (weapon.first == weaponKind::staff)
		 kind = "staff";
	 if (weapon.first == weaponKind::sword)
		 kind = "sword";
	 return kind;
}
 string Weapon::getweapontype() const {
	 string kind;
	 if (weapon.second == weaponType::one_handed)
		 kind = "one_handed";
	 if (weapon.second == weaponType::two_handed)
		 kind = "two_hannded";
	 return kind;
 }
 pair<double, double>Weapon::gethitdmg() const {
	 return hit_damage;
 }
 vector<pair<string, unsigned int>>Weapon::getWeaponEffects() const {
	 return effects;

 }