/**
* Solution to homework assignment 2
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author <Robert Borisov> m
* @idnumber <62529>
* @task <1>
* @compiler <VC>*/
#pragma once
#include "Weapon.hpp"
#include "Armor.hpp"
#include <iostream>
#include <vector>
template <class T>
class Equipment{
public:
	Equipment();
	bool isEmpty() const;
	bool isFull() const;
	void clearEquipment();
	void removeEquipment(int);
	T bestEquipment() const;
	bool operator==(const Equipment<T>& other);
	bool operator!=(const Equipment<T>& other);
	void addEquipment(const T item);
	size_t getSlots();
	vector<T> getVector() const;




private:
	vector <T> gear;
	size_t slots = 0;
};

template <class T>
vector<T> Equipment<T>::getVector()const {
	return gear;
}
template <class T>
size_t Equipment<T>::getSlots() {
	return this->slots;
}
template <class T>
Equipment<T>::Equipment() {
	slots = 0;
}
template <class T>
void Equipment<T>::addEquipment(const T item) {
	return;
}
template <>
 void Equipment<Weapon>::addEquipment(const Weapon item) {
	if (item.getWeaponType() == weaponType::two_handed) {
		if (gear.size() <= 22) {
			gear.push_back(item);
			slots += 2;
		}
		else {
			cout << "Insufficient space for this two-handed weapon!" << endl;
		}
	}
	else {
		if (gear.size() <= 23) {
			gear.push_back(item);
			slots += 2;
		}
		else {
			cout << "Insufficient space for this one-handed weapon!" << endl;
		}
	}
}
 template <>
void Equipment<Armor>::addEquipment(const Armor item) {
	if (gear.size() <= 23) {
		gear.push_back(item);
		slots += 1;
	}
	else {
		cout << "Insufficiennt space for this armor!" << endl;
	}
}
template <>
bool Equipment<Armor>::operator==(const Equipment<Armor>& other) {
	if (this->bestEquipment().gearScore() == other.bestEquipment().gearScore())
		return true;
	return false;
}
template <>
bool Equipment<Weapon>::operator==(const Equipment<Weapon>& other) {
	if (this->bestEquipment().WeaponScore() == other.bestEquipment().WeaponScore())
		return true;
	return false;
}
template <>
bool Equipment<Weapon>::operator!=(const Equipment<Weapon>& other) {
	if (*this == other)
		return false;
	else
		return true;
}
template <>
bool Equipment<Armor>::operator!=(const Equipment<Armor>& other) {
	if (*this == other)
		return false;
	else
		return true;
}



template <class T>
bool Equipment<T>::isEmpty() const {
	if (gear.size() == 0) {
		return true;
	}
	return false

}
template <>
bool Equipment<Weapon>::isFull() const {
	int slotsTaken = 0;
	for (int i = 0;i < gear.size();++i) {
		if (gear[i].getWeaponType() == weaponType::one_handed) {
			slotsTaken++;
		}
		else
			slotsTaken += 2;

	}
	if (slotsTaken == 24)
		return true;
		return false;
}
template <>
bool Equipment<Armor>::isFull() const {
	int slotsTaken = 0;
	slotsTaken == gear.size();
	if (slotsTaken == 24)
		return true;
	return false;
}
template <class T>
void Equipment<T>::clearEquipment() {
	for (int i = 0; i < gear.size();++i) {
		gear.pop_back();
	}
	slots = 0;
}


template <>
void Equipment<Armor>::removeEquipment(int index) {
	if (index >= gear.size()) {
		cout << "The index is out of bounnds" << endl;
	}
	else {

		gear.erase(gear.begin() + index);
		slots -= 1;
	}
}

template <>
void Equipment<Weapon>::removeEquipment(int index) {
	if (index >= gear.size()) {
		cout << "The index is out of bounnds" << endl;
	}
	else {

		gear.erase(gear.begin() + index);
		if (gear.at(index).getWeaponType() == weaponType::one_handed) {
			slots -= 1;
		}
		else {
			slots -= 2;
		}
	}
}
template <>
Armor Equipment<Armor>::bestEquipment() const {
	Armor item = gear[0];
	for (size_t i = 0;i < gear.size();++i) {
		if (item.gearScore() <= gear[i].gearScore()) {
			item = gear[i];
		}
	}
	return item;
}
template <>
Weapon Equipment<Weapon>::bestEquipment() const {
	Weapon item = gear[0];
	for (size_t i = 0;i < gear.size();++i) {
		if (item.WeaponScore() <= gear[i].WeaponScore()) {
			item = gear[i];
		}
	}
	return item;
}