/**
* Solution to homework assignment 2
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author <Robert Borisov> m
* @idnumber <62529>
* @task <1>
* @compiler <VC>*/
#pragma once
#include <utility>
using namespace std;
class Money {
	private:
	pair <unsigned int, unsigned int> gold_silver;
	public:
	Money();
	Money(unsigned int, unsigned int);
	void convert();
	void addSilver(unsigned int);
	void addGold(unsigned int);
	void removeGold(unsigned int);
	void removeSilver(unsigned int);
	size_t getGold();
	size_t getSilver();
	void setGold(unsigned int);
	void setSilver(unsigned int);
	bool isEmpty() const;
	void clear();
	
};