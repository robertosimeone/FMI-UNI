/**
* Solution to homework assignment 2
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author <Robert Borisov> m
* @idnumber <62529>
* @task <1>
* @compiler <VC>*/
#pragma once
#include <iostream>
using namespace std;
#include "Money.hpp"
#include "Materials.hpp"
template <class T>
class Backpack {
private:
	size_t slots = 0;
	T substance;

public:
	Backpack();
	bool isEmptyB() const;
	bool isFull() const;
	void clearBackpack();
	void addSubstance(T & substance);
	void removeSubstance(T&);
	size_t getSlots();
	T getBackpack()const;

};
template <class T>
T Backpack<T>::getBackpack()const {
	return substance;
}
template <class T>
size_t Backpack<T>::getSlots() {
	return this->slots;
}
 template <class T>
 Backpack<T>::Backpack() {
	 slots = 0;
 }

template <>
bool Backpack<Money>::isEmptyB() const {
	if (substance.isEmpty())
		return true;
	return false;
}
template <>
bool Backpack<Materials>::isEmptyB() const {
	if (substance.isEmpty())
		return true;
	return false;
}
template <class T >
bool Backpack<T>::isFull() const {
	return false;
}
template<>
bool Backpack<Materials>::isFull() const {
	size_t slots_taken = substance.slotsTaken();
	if (slots_taken == 16)
		return true;
	return false;
}
template <>
void Backpack<Money>::clearBackpack() {
	substance.clear();
	slots = 0;
}
template <>
void Backpack<Materials>::clearBackpack() {
	substance.clear();
	slots = 0;
}
template <class T>
void Backpack<T>::addSubstance(T& substance) {
}
template <>
void Backpack<Money>::addSubstance(Money& substance){
	this->substance.addGold(substance.getGold());
	this->substance.addSilver(substance.getSilver());
}
template <>
void Backpack<Materials>::addSubstance(Materials& substance){
	for (size_t i = 0;i < substance.getSize();++i) {
		if (slots + substance.slotsTaken() >= 17) {
			cout << "Sorry,unfortunately  your items have not been added.Reason: you are going beyond the limit" << endl;
			return;
		}
		this->substance.addMaterial(substance.getPairAtIndex(i));
		slots += substance.slotsTaken();
	}

}
template <class T>
void Backpack<T>::removeSubstance(T& remove) {

}
template <>
void Backpack<Money>::removeSubstance(Money & toRemove) {////////////////////////////////////////////
	if (substance.getGold() - toRemove.getGold() >= 0) {
		substance.removeGold(toRemove.getGold());
		cout << "You have successfully removed " << toRemove.getGold() <<" gold"<< endl;
	}
	else {
		cout << "You're trying to remove too much gold" << endl;
	}
	if (substance.getSilver() - toRemove.getSilver() >=0 ) {
		substance.removeSilver(toRemove.getSilver());
		cout << "You have successfully removed " << toRemove.getSilver() << " gold" << endl;
	}
	else {
		cout << "You're trying to remove too much silver" << endl;
	}

}
template <>
void Backpack<Materials>::removeSubstance(Materials& toRemove) {
	substance.removeMaterial(toRemove);
	slots = substance.slotsTaken();
}