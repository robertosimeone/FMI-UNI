/**
* Solution to homework assignment 2
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author <Robert Borisov> m
* @idnumber <62529>
* @task <1>
* @compiler <VC>*/
#pragma once
#include <utility>
#include <string>
#include <vector>
#include <string>
using namespace std;

enum class weaponType {
	one_handed,
	two_handed,
};
enum class weaponKind {
	axe,
	sword,
	dagger,
	mace,
	staff,

};

class Weapon {
public:
	Weapon();
	double  WeaponScore() const;
	void changeWeaponType(weaponType&);
	void changeWeaponKind(weaponKind&);
	void addEffect(pair<string, unsigned int>&);
	void changeEffectPower(string,unsigned int);
	void removeEffect(string);
	weaponType getWeaponType() const;
	string getweaponkind() const;
	string getweapontype() const;
	pair<double, double> gethitdmg() const;
	vector<pair<string, unsigned int>> getWeaponEffects() const;
	Weapon(const Weapon&);
	Weapon& operator=(const Weapon&);

	void setHitDmg(double lowest_value, double max_value);
	
	static Weapon createAxe();
	static Weapon createSword();
	static Weapon createDagger();
	static Weapon createMace();
	static Weapon createStaff();


private:
	pair <weaponKind, weaponType> weapon;
	pair<double, double> hit_damage;
	vector<pair<string, unsigned int>> effects;

		
};