/**
* Solution to homework assignment 2
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author <Robert Borisov> m
* @idnumber <62529>
* @task <1>
* @compiler <VC>*/
#pragma once
using namespace std;
#include "Equipment.hpp"
#include "Backpack.hpp"
#include <vector>
template <class T>
class Inventory{
private:
	T substance;

public:
	T getSubstance() const;
	bool operator==(const Inventory<T>& other);
	bool operator!=(const Inventory<T>& other);

	friend ostream& operator<<(ostream& out,const Inventory<Equipment<Armor>> & print);
	friend ostream& operator<<(ostream& out, const Inventory<Equipment<Weapon>>& print);
	friend ostream& operator<<(ostream& out, const Inventory<Backpack<Money>>& print);
	friend ostream& operator<<(ostream& out, const Inventory<Backpack<Materials>>& print);



};

template<>
bool Inventory<Equipment<Armor>>::operator==(const Inventory<Equipment<Armor>>& other)
{
	if (substance.getSlots() == other.getSubstance().getSlots())
		return true;
	else
		return false;
}
template<>
bool Inventory<Equipment<Weapon>>::operator==(const Inventory<Equipment<Weapon>>& other)
{
	if (substance.getSlots() == other.getSubstance().getSlots())
		return true;
	else
		return false;
}
template<>
bool Inventory<Backpack<Money>>::operator==(const Inventory<Backpack<Money>>& other)
{
	if (substance.getSlots() == other.getSubstance().getSlots())
		return true;
	else
		return false;
}
template<>
bool Inventory<Backpack<Materials>>::operator==(const Inventory<Backpack<Materials>>& other)
{
	if (substance.getSlots() == other.getSubstance().getSlots())
		return true;
	else
		return false;
}
template <>
bool Inventory<Equipment<Weapon>>::operator!=(const Inventory<Equipment<Weapon>>& other) {
	if (*this == other)
		return false;
	return true;
}
template <>
bool Inventory<Equipment<Armor>>::operator!=(const Inventory<Equipment<Armor>>& other) {
	if (*this == other)
		return false;
	return true;
}
template <>
bool Inventory<Backpack<Money>>::operator!=(const Inventory<Backpack<Money>>& other) {
	if (*this == other)
		return false;
	return true;
}
template <>
bool Inventory<Backpack<Materials>>::operator!=(const Inventory<Backpack<Materials>>& other) {
	if (*this == other)
		return false;
	return true;
}
template <class T>
T Inventory<T>::getSubstance() const {
	return substance;
}
template<class T>
ostream& operator<<(ostream& out, Inventory<T>& print) {

	return out;
}
ostream& operator<<(ostream& out,const Inventory<Equipment<Armor>>& print){
	vector<Armor> armor = print.getSubstance().getVector();
	vector<pair<string, unsigned int>> armoreffects;
	for (size_t i = 0; i < armor.size();++i) {
		out << armor[i].getArmor() << " " << armor[i].getDefense() << " " << endl << "effects ";
		armoreffects = armor[i].getEffects();
		for (size_t i = 0;i < armoreffects.size();++i) {
			out << armoreffects[i].first << ": " << armoreffects[i].second << " ";
		}
		out << endl;
	}
	return out;
}
ostream& operator<<(ostream& out, const Inventory<Equipment<Weapon>>& print) {
	vector<Weapon> weapon = print.getSubstance().getVector();
	for (size_t i = 0;i < weapon.size();++i) {
		pair <double, double> hit_dmg = weapon[i].gethitdmg();
		out << weapon[i].getweaponkind() << " " << weapon[i].getweapontype() << hit_dmg.first << " " << hit_dmg.second << " " << endl << "effects ";
		vector<pair<string, unsigned int>> effects = weapon[i].getWeaponEffects();
		for (size_t i = 0;i < effects.size();++i) {
			out << effects[i].first << ": " << effects[i].second << " ";
		}
		out << endl;
	}

	return out;
}
ostream& operator<<(ostream& out, const Inventory<Backpack<Money>>& print) {
	Money money = print.getSubstance().getBackpack();
	out << money.getGold() << " " << money.getSilver();
	return out;
}
ostream& operator<<(ostream& out, const Inventory<Backpack<Materials>>& print) {
	vector<pair<materialType, unsigned int>>materials = print.getSubstance().getBackpack().getmaterials();
	string type;
	for (size_t i = 0;i < materials.size();++i) {
		if (materials[i].first == materialType::cloth)
			type = "cloth";
		if (materials[i].first == materialType::essence)
			type = "essence";
		if (materials[i].first == materialType::herb)
			type = "cloth";
		if (materials[i].first == materialType::ores)
			type = "ores";
		out << type << ": " << materials[i].second << endl;
	}
	
	return out;
}