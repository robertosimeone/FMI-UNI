/**
* Solution to homework assignment 2
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author <Robert Borisov> m
* @idnumber <62529>
* @task <1>
* @compiler <VC>*/
#include "Money.hpp"
#include <iostream>
Money::Money() {
	gold_silver.first = 0;
	gold_silver.second = 0;
}
Money::Money(unsigned int gold, unsigned int silver){
	gold_silver.first = gold;
	gold_silver.second = silver;
	this->convert();
}
void Money::addGold(unsigned int gold) {
	gold_silver.first = gold;
}
void Money::addSilver(unsigned int silver) {
	gold_silver.second = silver;
	this->convert();
}
size_t Money::getGold() {
	return gold_silver.first;
}
size_t Money::getSilver() {
	return gold_silver.second;
}
void Money::removeGold(unsigned int gold) {
	if (gold > gold_silver.first)
		cout << "Sorry, your action has been cancelled,you're trying to remove too much gold" << endl;
	else {
		gold_silver.first -= gold;
	}
}
void Money::removeSilver(unsigned int silver) {
	if (silver > gold_silver.second)
		cout << "Sorry, your action has been cancelled,you're trying to remove too much silver" << endl;
	else {
		gold_silver.second -= silver;
	}
}
void Money::setGold(unsigned int gold) {
	gold_silver.first = gold;
}
void Money::setSilver(unsigned int silver) {
	gold_silver.second = silver;
	this->convert();
}
void Money::convert(){
	if (gold_silver.second >= 100) {
		gold_silver.first += gold_silver.second / 100;
		gold_silver.second %= 100;
	}

}
bool Money::isEmpty() const {
	if (gold_silver.first == 0 and gold_silver.second == 0)
		return true;
	return false;
}
void Money::clear() {
	gold_silver.first = 0;
	gold_silver.second = 0;
}
