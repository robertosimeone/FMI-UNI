/**
* Solution to homework assignment 3
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author Robert Borisov
* @idnumber 62529
* @task 1
* @compiler clang */

#ifndef OOPPRAKTIKUM3_CARD_HPP
#define OOPPRAKTIKUM3_CARD_HPP

#include <string>
using namespace std;
class Card {
string name;
string effect;
public:
Card(string,string) ;
void setName(string name);
void setEffect(string effect);
string getName() const;
string getEffect() const;
};


#endif //OOPPRAKTIKUM3_CARD_HPP
