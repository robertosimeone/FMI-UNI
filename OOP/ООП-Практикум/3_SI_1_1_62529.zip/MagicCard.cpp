/**
* Solution to homework assignment 3
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author Robert Borisov
* @idnumber 62529
* @task 1
* @compiler clang */
#include "MagicCard.hpp"
#include <iostream>
using namespace std;
MagicCard::MagicCard(string name, string effect, Type type) :Card(name,effect){
    this->type = type;
}

MagicCard& MagicCard::operator=(const MagicCard& other) {
    if (this != &other) {
        setName(other.getName());
        setEffect(other.getEffect());
        this->type = other.type;
    }
    return *this;
}


Type MagicCard::fromstringtotype(string effect) const{
   if(effect == "TRAP")
       return Type::trap;
   if(effect == "BUFF")
       return Type::buff;
   return Type::spell;
}

void MagicCard::setType(Type type) {
this->type = type;
}
ostream &operator<<(ostream &out, const MagicCard & card) {
    string between = "|";
    string combined = card.getName()+between+card.getEffect()+between+card.fromtypetostring(card.type);
    out<<combined<<endl;
    return out;
}

istream &operator>>(istream &is, MagicCard & card) {
    string name;
    string effect;
    Type type;
    string typestring;
    getline(is, name, '|');
    getline(is, effect, '|');
    getline(is, typestring, '\n');
    type = card.fromstringtotype(typestring);
    card.setEffect(effect);
    card.setName(name);
    card.setType(type);
    return is;
}


string MagicCard::fromtypetostring(Type type) const {
    string outstring = "";
    if(type==Type::spell)
        outstring = "SPELL";
    if(type == Type::buff )
        outstring = "BUFF";
    if(type==Type::trap)
        outstring = "TRAP";
    return outstring;
}

Type MagicCard::getType() const {
    return this->type;
}
