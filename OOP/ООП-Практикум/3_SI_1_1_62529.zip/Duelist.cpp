/**
* Solution to homework assignment 3
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author Robert Borisov
* @idnumber 62529
* @task 1
* @compiler clang  */

#include "Duelist.hpp"
Deck& Duelist::getDeck() {
    return deck;
}
Duelist::Duelist(string name){
    this->name = name;
}

bool Duelist::saveDeckToFile(string filename) {//check for new lines when u print in the file
    ofstream file(filename);
    char separator = '|';
    if(file){
        file<<this->getDeck().getName()<<separator<<this->getDeck().getMonstersCount()<<separator<<this->getDeck().getSpellsCount()<<separator<<this->getDeck().getPendulumsCount()<<endl;
        for( size_t i = 0;i<getDeck().getMonstersCount();++i){
        file<<getDeck().getMonsterCards()[i];
        }
        for( size_t i = 0;i<getDeck().getSpellsCount();++i){
            file<<getDeck().getMagicCards()[i];
        }
        for( size_t i = 0;i<getDeck().getPendulumsCount();++i){
            file<<getDeck().getPendulums()[i];
        }

        return true;
    }
    else{
        return false;
    }
}

bool Duelist::loadDeckFromFile(string filename) {
    ifstream file(filename);
    if(file){
        char trash;
        size_t monstercount = 0 ;
        size_t spellscount  = 0;
        size_t pendulumscount = 0;
        string deckname;
        getline(file,deckname,'|');
        file>>monstercount>>trash>>spellscount>>trash>>pendulumscount;
        this->getDeck().setName(deckname);
        MonsterCard monster;
        MagicCard magic;
        PendulumCard pendulum;
        for(size_t i = 0 ;i<monstercount;++i){
            file>>monster;
            this->getDeck().addMonster(monster);
        }
        for(size_t i = 0 ;i<spellscount;++i){
            file>>magic;
            this->getDeck().addSpells(magic);
        }
        for(size_t i = 0 ;i<pendulumscount;++i){
            file>>pendulum;
            this->getDeck().addPendulum(pendulum);
        }
        return true;
    }else{
        return false;
    }
}
