/**
* Solution to homework assignment 3
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author Robert Borisov
* @idnumber 62529
* @task 1
* @compiler  clang */

#include "Deck.hpp"
size_t Deck::getMonstersCount() const {
    return this->monsters.size();
}
size_t Deck::getSpellsCount() const {
    return this->spells.size();
}
size_t Deck::getPendulumsCount() const {
    return this->pendulum.size();
}
void Deck::addMonster(MonsterCard card) {
    monsters.push_back(card);
}
void Deck::addSpells(MagicCard card) {
    spells.push_back(card);
}
void Deck::addPendulum(PendulumCard card) {
    pendulum.push_back(card);
}
void Deck::changeMagicCard(size_t index, MagicCard card) {
    spells[index] = card;
}
void Deck::changeMonsterCard(size_t index, MonsterCard card) {
    monsters[index] = card;
}

string Deck::getName() const {
    return this->name;
}

vector<PendulumCard> &Deck::getPendulums() {
    return pendulum;
}

vector<MagicCard> &Deck::getMagicCards() {
    return spells;
}

vector<MonsterCard> &Deck::getMonsterCards() {
    return monsters;
}

void Deck::clearDeck() {
this->name = "";
monsters.clear();
spells.clear();
pendulum.clear();
}

void Deck::setName(string name) {
    this->name = name;

}
