/**
* Solution to homework assignment 3
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author Robert Borisov
* @idnumber 62529
* @task 1
* @compiler  clang */

#pragma once

using namespace std;
#include "Card.hpp"
#include <string>
enum Type {
    trap = 0,
    buff = 1,
    spell = 2
};
class MagicCard : virtual public Card{
    Type type;
public:
    Type fromstringtotype(string) const ;
    string fromtypetostring(Type) const;
    MagicCard(string name = "", string effect = "", Type type = buff);
    MagicCard& operator=(const MagicCard& other);
   friend  ostream& operator<<(ostream & out,const MagicCard &);
   friend istream& operator>>(istream& is,MagicCard&);
   void setType(Type type);
   Type getType()const;
};





