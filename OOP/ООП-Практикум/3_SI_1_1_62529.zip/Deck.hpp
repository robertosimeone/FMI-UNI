/**
* Solution to homework assignment 3
* Object Oriented Programming Course
* Faculty of Mathematics and Informatics of Sofia University
* Summer semester 2020/2021 *
* @author Robert Borisov
* @idnumber 62529
* @task 1
* @compiler  clang */

#ifndef OOPPRAKTIKUM3_DECK_HPP
#define OOPPRAKTIKUM3_DECK_HPP
#include <string>
#include <vector>
#include "MonsterCard.hpp"
#include "MagicCard.hpp"
#include "PendulumCard.hpp"
using namespace std;

class Deck {

    string name;
    vector<MonsterCard> monsters;
    vector<MagicCard> spells;
    vector<PendulumCard> pendulum;

public:
    void setName(string name);
    string getName() const;
    size_t getMonstersCount() const;
    size_t getSpellsCount() const;
    size_t getPendulumsCount() const;
    void addMonster( MonsterCard card);
    void addSpells( MagicCard card);
    void addPendulum( PendulumCard card);
    void changeMonsterCard(size_t index, MonsterCard card);
    void changeMagicCard(size_t index,  MagicCard card);
    vector<PendulumCard> & getPendulums();
    vector<MagicCard> & getMagicCards();
    vector<MonsterCard> & getMonsterCards();
    void clearDeck();
    //display deck

};


#endif //OOPPRAKTIKUM3_DECK_HPP
