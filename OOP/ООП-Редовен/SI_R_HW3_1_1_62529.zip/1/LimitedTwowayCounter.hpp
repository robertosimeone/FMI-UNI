//
// Created by Robert Borisov on 7.05.21.
//

#ifndef UNTITLED2_LIMITEDTWOWAYCOUNTER_HPP
#define UNTITLED2_LIMITEDTWOWAYCOUNTER_HPP
#include "TwowayCounter.hpp"
#include "LimitedCounter.hpp"

class LimitedTwowayCounter:  public LimitedCounter, public TwowayCounter {
const int MIN_VALUE;
public:
    LimitedTwowayCounter(int min, int max);
    LimitedTwowayCounter(int min, int max,  int initial);
    LimitedTwowayCounter(int min, int max , int initial , size_t step);
    void increment();
    void decrement();
    int getMin() const;
    int getMax() const;
    int getTotal() const;
    size_t getStep() const;

};


#endif //UNTITLED2_LIMITEDTWOWAYCOUNTER_HPP
