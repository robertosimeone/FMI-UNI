//
// Created by Robert Borisov on 7.05.21.
//

#include "LimitedCounter.hpp"

LimitedCounter::LimitedCounter(int max) :Counter(0,1),MAX_VALUE(max) {

}

LimitedCounter::LimitedCounter(int max, int initial) : Counter(initial,1) , MAX_VALUE(max)  {

}

LimitedCounter::LimitedCounter(int max, int initial, size_t step) : Counter(initial,step) ,MAX_VALUE(max) {
}

void LimitedCounter::increment() {
if(getTotal()+(int)getStep()>MAX_VALUE)
    return;
   Counter::setInitial(Counter::getTotal()+(int)Counter::getStep());
}

int LimitedCounter::getMax() const {
    return MAX_VALUE;
}

int LimitedCounter::getTotal() const {
    return Counter::getTotal();
}

size_t LimitedCounter::getStep() const {
    return Counter::getStep();
}


