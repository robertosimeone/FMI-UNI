//
// Created by Robert Borisov on 7.05.21.
//

#ifndef UNTITLED2_TWOWAYCOUNTER_HPP
#define UNTITLED2_TWOWAYCOUNTER_HPP
using namespace std;
#include <iostream>
#include "Counter.hpp"
class TwowayCounter:virtual  public Counter {
public:
    TwowayCounter(int initial = 0 ,size_t step = 1);
    void decrement();
};


#endif //UNTITLED2_TWOWAYCOUNTER_HPP
