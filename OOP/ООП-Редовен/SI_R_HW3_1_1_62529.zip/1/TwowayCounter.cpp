//
// Created by Robert Borisov on 7.05.21.
//

#include "TwowayCounter.hpp"

void TwowayCounter::decrement() {
this->setInitial(this->getTotal()-this->getStep());
}

TwowayCounter::TwowayCounter(int initial, size_t step) : Counter(initial, step){
}
