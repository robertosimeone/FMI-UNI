//
// Created by Robert Borisov on 7.05.21.
//

#ifndef UNTITLED2_SEMAPHORE_HPP
#define UNTITLED2_SEMAPHORE_HPP
#include "LimitedTwowayCounter.hpp"

class Semaphore: public LimitedTwowayCounter {
public:
    Semaphore();
    Semaphore(bool);
    bool isAvaible() const;
    void wait();
    void signal();
};


#endif //UNTITLED2_SEMAPHORE_HPP
