//
// Created by Robert Borisov on 7.05.21.
//

#include "Counter.hpp"

Counter::Counter() {
initial = 0;
step = 1;
}

Counter::Counter(int initial) {
this->initial = initial;
step = 1;

}

Counter::Counter(int initial, size_t step) {
this->initial  = initial;
this->step = step;
}

void Counter::increment() {
this->initial+=(int)step;
}

int Counter::getTotal() const {
    return  this->initial;
}

size_t Counter::getStep() const {
    return this->step;
}

void Counter::setInitial(int initial) {
this->initial = initial;
}
