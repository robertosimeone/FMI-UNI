//
// Created by Robert Borisov on 7.05.21.
//

#include "LimitedTwowayCounter.hpp"

void LimitedTwowayCounter::increment() {
    if(LimitedCounter::getTotal()+ (int)LimitedCounter::getStep()>LimitedCounter::getMax())
        return;
    LimitedCounter::increment();
}

LimitedTwowayCounter::LimitedTwowayCounter(int min, int max) : LimitedCounter(max, 0,1)  ,TwowayCounter(0,1), Counter(0,1),MIN_VALUE(min){

}

LimitedTwowayCounter::LimitedTwowayCounter(int min, int max, int initial): LimitedCounter(max,initial,1),TwowayCounter(initial,1),Counter(initial,1),MIN_VALUE(min){

}

LimitedTwowayCounter::LimitedTwowayCounter(int min, int max, int initial, size_t step): LimitedCounter(max, initial, step),
                                                                                        TwowayCounter(initial,step),Counter(initial,step), MIN_VALUE(min) {
}

void LimitedTwowayCounter::decrement() {
    if(LimitedCounter::getTotal() - (int)LimitedCounter::getStep()<MIN_VALUE)
        return;
    TwowayCounter::decrement();
}

int LimitedTwowayCounter::getMin() const {
    return MIN_VALUE ;
}

int LimitedTwowayCounter::getMax() const {
    return LimitedCounter::getMax();
}

int LimitedTwowayCounter::getTotal() const {
    return LimitedCounter::getTotal();
}

size_t LimitedTwowayCounter::getStep() const {
    return Counter::getStep();
}

