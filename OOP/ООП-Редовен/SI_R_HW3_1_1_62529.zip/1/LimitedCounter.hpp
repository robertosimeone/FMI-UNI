//
// Created by Robert Borisov on 7.05.21.
//

#ifndef UNTITLED2_LIMITEDCOUNTER_HPP
#define UNTITLED2_LIMITEDCOUNTER_HPP
#include <iostream>
using namespace std;
#include "Counter.hpp"
class LimitedCounter : virtual  public Counter{
const int MAX_VALUE;
public:
    LimitedCounter(int);
    LimitedCounter(int , int);
    LimitedCounter(int , int, size_t);
    void increment();
    int getMax() const;
    int getTotal() const;
    size_t getStep() const;


};


#endif //UNTITLED2_LIMITEDCOUNTER_HPP
