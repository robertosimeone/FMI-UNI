//
// Created by Robert Borisov on 7.05.21.
//

#include "Semaphore.hpp"

Semaphore::Semaphore(): LimitedTwowayCounter(0,1,0,1) {

}

Semaphore::Semaphore(bool flag): LimitedTwowayCounter(0,1,flag,1){

}

bool Semaphore::isAvaible() const {
   if(getTotal()>0)
       return true;
   return false;
}

void Semaphore::wait() {
LimitedTwowayCounter::decrement();
}

void Semaphore::signal() {
LimitedTwowayCounter::increment();
}
