//
// Created by Robert Borisov on 7.05.21.
//

#ifndef UNTITLED2_COUNTER_HPP
#define UNTITLED2_COUNTER_HPP
using namespace std;
#include <iostream>
class Counter {
int initial;
size_t step;
public:
    Counter();
    Counter(int);
    Counter(int,size_t);
    void increment();
    int getTotal() const;
    size_t getStep() const;
    void setInitial(int);



};


#endif //UNTITLED2_COUNTER_HPP
