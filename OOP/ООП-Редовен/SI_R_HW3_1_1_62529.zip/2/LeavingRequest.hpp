//
// Created by Robert Borisov on 7.05.21.
//

#ifndef INC_2_LEAVINGREQUEST_HPP
#define INC_2_LEAVINGREQUEST_HPP
#include "Request.hpp"

class LeavingRequest: public Request {
public:
    LeavingRequest(const string & sender);

};


#endif //INC_2_LEAVINGREQUEST_HPP
