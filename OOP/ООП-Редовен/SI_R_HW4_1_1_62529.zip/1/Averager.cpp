//
// Created by Robert Borisov on 30.05.21.
//

#include "Averager.hpp"

int Averager::read() const {
    int result = 0;
    if(messages.size() == 0){
        return 0;
    }
    int sum = 0;
    for( auto message : messages){
         sum +=message.data;
    }
    result = sum/(int)messages.size();
    return result;
}

void Averager::signal(Message message) {
messages.push_back(message);
}

Averager::Averager(std::string id) : Subscriber(id) {
}

Subscriber *Averager::clone() const {
    return new Averager(*this);
}

