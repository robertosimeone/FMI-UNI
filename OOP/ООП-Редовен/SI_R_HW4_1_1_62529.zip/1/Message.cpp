//
// Created by Robert Borisov on 30.05.21.
//

#include "Message.hpp"

Message::Message(int data) : data(data){
}
