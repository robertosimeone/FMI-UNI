//
// Created by Robert Borisov on 30.05.21.
//

#include "BacklogPublisher.hpp"

void BacklogPublisher::subscribe(Averager * averager) {
   this->getSubscribers().push_back(averager);
   for(auto message : messages){
       averager->signal(message);
   }
}

void BacklogPublisher::subscribe(MovingAverager * movingAverager) {
    this->getSubscribers().push_back(movingAverager);
    for(auto message : messages){
        movingAverager->signal(message);
    }

}

void BacklogPublisher::subscribe(PeriodicSampler * periodicSampler) {
    this->getSubscribers().push_back(periodicSampler);
    for(auto message : messages){
        periodicSampler->signal(message);
    }

}

void BacklogPublisher::signal(Message message) {
    messages.push_back(message);
    for (auto subscriber : this->getSubscribers()) {
        subscriber->signal(message);
    }
}

