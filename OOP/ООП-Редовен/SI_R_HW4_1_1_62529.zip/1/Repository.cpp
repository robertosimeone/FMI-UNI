//
// Created by Robert Borisov on 30.05.21.
//

#include "Repository.hpp"



void Repository::add(Averager * averager) {
subscribers.push_back(averager->clone());
}

void Repository::add(MovingAverager * movingAverager) {
subscribers.push_back(movingAverager->clone());
}

void Repository::add(PeriodicSampler * periodicSampler) {
    subscribers.push_back(periodicSampler->clone());
}

Subscriber *Repository::get(std::string id) {
    for(auto subscriber : subscribers) {
        if (subscriber->getID() == id) {
            return subscriber;
        }
    }
    return nullptr;
}

Repository &Repository::operator=(const Repository &repository) {
    if(this!=&repository){
        for(auto subscriber : subscribers){
            delete subscriber;
        }
        subscribers.clear();
        for(auto subscriber : repository.subscribers){
            subscribers.push_back(subscriber->clone());
        }
    }
    return *this;
}

Repository::Repository(const Repository &repository) {
    for (auto subscriber : repository.subscribers) {
        subscribers.push_back(subscriber->clone());
    }
}





Repository::~Repository() {
    for(auto subscriber : subscribers){
        delete subscriber;
    }

}
