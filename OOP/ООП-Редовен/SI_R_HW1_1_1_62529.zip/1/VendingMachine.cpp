#include <iostream>
#include "VendingMachine.hpp"
using namespace std;
VendingMachine::VendingMachine() {
	capacity = 10;
	drinks = new Drink[capacity];
	count = 0;
	income = 0;
}
VendingMachine::VendingMachine(const VendingMachine& from) {
	this->capacity = from.capacity;
	this->count = from.count;
	this->income = from.income;
	drinks = new Drink[capacity];
	for (int i = 0;i < count;i++) {
		drinks[i] = from.drinks[i];
	}
}
VendingMachine& VendingMachine::operator=(const VendingMachine& from) {
	if (this != &from) {
		this->capacity = from.capacity;
		this->count = from.count;
		this->income = income;
		delete[] drinks;
		drinks = new Drink[capacity];
		for (int i = 0;i < count;i++) {
			drinks[i] = from.drinks[i];
		}
	}
	return *this;
}
VendingMachine::~VendingMachine() {
	delete[] drinks;
}
bool VendingMachine::add_drink(const Drink& to_add) {
	bool exists = this->doesExist(to_add.get_name());

	if (!exists) {
		if (capacity == count) {
			this->resize();
		}
		//check if there's space
		drinks[count] = to_add;
		count++;

	}
	return exists;
}
int VendingMachine::buy_drink(const char* drink_name, const double money) {
	int index = 0;
	if (!this->doesExist(drink_name)) {
		return 2;
	}
	else {
		index = indexOfElement(drink_name);
		if (drinks[index].get_price() > money) {
			income += money;
			return 1;
		}
		else {
			income += money;
			this->removeDrink(index);
			return 0;
		}
	}

}
bool VendingMachine::doesExist(const char* drink_name) const {
	bool exists = false;
	for (int i = 0;i < count;i++) {
		if (strcmp(drinks[i].get_name(), drink_name) == 0) {
			exists = true;
			break;
		}
	}
	return exists;
}
int VendingMachine::indexOfElement(const char* drink_name) const {
	for (int i = 0;i < this->count;i++) {
		if (strcmp(drinks[i].get_name(), drink_name) == 0) {
			return i;
		}
	}
	return 0;
///////////////////////////
}
void VendingMachine::removeDrink(int indexOfElement) {
	int indexNewElement = 0;
	Drink* newDrinks = new Drink[capacity];
	for (int i = 0;i < count;i++) {
		if (i != indexOfElement) {
			newDrinks[indexNewElement] = drinks[i];
			indexNewElement++;
		}
	}
	count--;
	delete[] drinks;
	drinks = newDrinks;
}
double VendingMachine::get_income() const {
	return this->income;
}
void VendingMachine::resize() {
		Drink* newDrinks = new Drink[capacity * 2];
			capacity = capacity * 2;
			for (int i = 0;i < count;i++) {
				newDrinks[i] = drinks[i];
			}

}
