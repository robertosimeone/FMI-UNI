#pragma warning(disable : 4996)
#include <iostream>
#include "drink.hpp"
#include <string.h>
using namespace std;
double Drink::get_calories() const {
	return this->calories;
}
double Drink::get_quantity() const	{
	return this->quantity;
}
double Drink::get_price() const {
	return this->price;
}
const char* Drink::get_name() const {
	return this->name;
}
void Drink::set_name(const char * newName) {
		delete[] name;
		int newNameSize = strlen(newName) + 1;
		name = new char[newNameSize];
		strncpy(name, newName, newNameSize);
}
Drink::Drink() {
	 name = nullptr;
	 quantity = 0;
	 calories = 0;
	 price = 0;
}
Drink::Drink(const char* init_name, const int init_calories, const double& init_quantity, const double& init_price) {
	int size = strlen(init_name)+1;
	this->name = new char[size];
	strncpy(name, init_name, size);
	calories = init_calories;
	quantity = init_quantity;
	price = init_price;

}
Drink::Drink(const Drink& newDrink) {
	int newNameSize = strlen(newDrink.get_name()) + 1;
	name = new char[newNameSize];
	strncpy(name, newDrink.get_name(), newNameSize);
	calories = newDrink.calories;
	quantity = newDrink.quantity;
	price = newDrink.price;
}	
Drink::~Drink() {
	delete[] name;
}
Drink& Drink::operator=(const Drink& newDrink) {
	if (this != &newDrink) {
	this->set_name(newDrink.get_name());
		calories = newDrink.calories;
		quantity = newDrink.quantity;
		price = newDrink.price;
	}
	return *this;
}