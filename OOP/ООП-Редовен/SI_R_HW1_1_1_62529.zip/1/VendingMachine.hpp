#include "drink.hpp"
#ifndef VENDING_MACHINE 
#define VENDING_MACHINE 1   
class VendingMachine {
public:
    VendingMachine();
    VendingMachine(const VendingMachine& from);
    VendingMachine& operator=(const VendingMachine& from);
    ~VendingMachine();

    bool add_drink(const Drink& to_add);
    int buy_drink(const char* drink_name, const double money);

    double get_income() const;
    int indexOfElement(const char* drink_name) const;
    bool doesExist(const char * drink_name) const;
    void removeDrink(int indexOfElement);
    void resize();


    // Add whatever you deem needed here
private:
    // Add whatever you deem needed here
    Drink* drinks;
    int capacity;
    int count;
    double income;
};  
#endif