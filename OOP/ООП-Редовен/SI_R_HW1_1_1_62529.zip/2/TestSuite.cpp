#include "TestSuite.hpp"
using namespace std;
TestSuite::TestSuite(std::string name) {
	this->name = name;
}
void TestSuite::add(const TestCase& newTestCase) {
	testcases.push_back(newTestCase);
}
std::vector<TestCase> TestSuite::filterPassing() const {
	std::vector <TestCase> passingcases;
	for (size_t i = 0;i < testcases.size();++i) {
		if (testcases[i].isPassing()) {
			passingcases.push_back(testcases[i]);
		}
	}
	return passingcases;
}
void TestSuite::setName(const std::string& name) {
	this->name = name;
}
std::string TestSuite::getName() const {
	return this->name;

}
std::vector<TestCase> TestSuite::filterFailing() const {
	std::vector <TestCase> failingcases;
	for (size_t i = 0;i < testcases.size();++i) {
		if (!testcases[i].isPassing()) {
			failingcases.push_back(testcases[i]);
		}
	}
	return failingcases;
}
std::vector<TestCase> TestSuite::filterByErrorType(ErrorType type) const {
	std::vector <TestCase> errortypecases;
	for (size_t i = 0;i < testcases.size();++i) {
		if (testcases[i].getErrorType() == type) {
			errortypecases.push_back(testcases[i]);
		}
	}
	return errortypecases;

}
void TestSuite::removeByErrorType(ErrorType type){
	std::vector <TestCase> remainingcases;
	for (size_t i = 0;i < testcases.size();++i) {
		if (testcases[i].getErrorType() != type) {
			remainingcases.push_back(testcases[i]);
		}///////////////////////////
	}
	testcases = remainingcases;
}