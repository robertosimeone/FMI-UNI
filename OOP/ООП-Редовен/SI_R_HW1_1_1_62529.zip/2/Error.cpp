#pragma warning(disable : 4996)
#include "Error.hpp"
using namespace std;
#include <iostream>
Error::Error() {
	message = nullptr;
	errorType = ErrorType::None;
}
Error::Error(const Error& copyFrom) {
	this->setMessage(copyFrom.message);
	this->errorType = copyFrom.errorType;
}
Error& Error::operator=(const Error& copyFrom) {
	if (this != &copyFrom) {
		delete[] message;
		this->setMessage(copyFrom.message);
		this->errorType = copyFrom.errorType;
	}
	return *this;
}
Error::~Error() {
	delete[] message;
}
Error Error::newBuildFailed(const char* message) {
	Error newError;
	newError.errorType = ErrorType::BuildFailed;
	int size = strlen(message);
	newError.message = new char[size + 1];
	strncpy(newError.message, message, size + 1);
	newError.message[size] = '\0';
	return newError;


}

bool Error::hasMessage() const {
	if (message != nullptr) {
		return true;
	}
	else
		return false;
}
const char* Error::getMessage() const {
	if (message != nullptr)
		return this->message;
	else
		return nullptr;////check this thing 
}
ErrorType Error::getType() const {
	return this->errorType;
}

Error Error::newNone(){
	Error newError;
	return newError;
}

Error Error::newWarning(const char* message)
{
	Error newError;
	newError.errorType = ErrorType::Warning;
	int size = strlen(message);
	newError.message = new char[size + 1];
	strncpy(newError.message, message, size + 1);
	newError.message[size] = '\0';
	return newError;
	
}
void Error::setMessage(const char* message) {
	if (message == nullptr) {
		this->message = nullptr;
	}
	else {
		int size = strlen(message);
		this->message = new char[size + 1];
		strncpy(this->message, message, size + 1);
		this->message[size] = '\0';
	}
}
Error Error::newFailedAssertion(const char* message) {
	Error newError;
	newError.errorType = ErrorType::FailedAssertion;
	int size = strlen(message);
	newError.message = new char[size + 1];
	strncpy(newError.message, message, size + 1);
	newError.message[size] = '\0';
	return newError;
}

