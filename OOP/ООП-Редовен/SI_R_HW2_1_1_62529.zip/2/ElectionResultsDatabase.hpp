#pragma once
#include "SectionVotes.hpp"
#include <fstream>
#include <vector>
using namespace std;
// Add whatever else is required to exist in or out the class
// as well as whatever you think is good to be declared too

class ElectionResultsDatabase
{
    vector<SectionVotes> sections;
    vector<int> parties;
    size_t countOfLines(istream&)const;
    void setTotalVotes();
public:
    ElectionResultsDatabase();
    void addResultsFromFile(const char* filename);

 
    int votesForParty(Party) const;
    int numberOfSections() const;
    Party winningParty() const;
    vector<SectionVotes> getSections() const;
    void addSection(SectionVotes&);

    friend ostream& operator<<(ostream& out, const ElectionResultsDatabase& votes);
    friend istream& operator>>(std::istream& in, ElectionResultsDatabase& votes);

};