#include "ElectionResultsDatabase.hpp"
#include <iostream>
#include <string>
ElectionResultsDatabase::ElectionResultsDatabase() {
	for (int i = 0;i < 3;i++)
		this->parties.push_back(0);
}
int ElectionResultsDatabase::numberOfSections() const {
	return this->sections.size();
}
int ElectionResultsDatabase::votesForParty(Party party) const {
	if (party == PARTY1)
		return parties[0];
	if (party == PARTY2)
		return parties[1];
	if (party == PARTY3)
		return parties[2];
	return 0;
}
Party ElectionResultsDatabase::winningParty() const {
	int index = 0;
		for (size_t i = 1;i < parties.size();++i) {
			if (parties[i] > parties[index])
				index = i;
		}
		if (index == 0)
			return Party::PARTY1;
		if (index == 1)
			return Party::PARTY2;
		return Party::PARTY3;	
}

vector<SectionVotes> ElectionResultsDatabase::getSections() const {
	return sections;
}
size_t ElectionResultsDatabase::countOfLines(istream& in)const {
	string line;
	size_t line_number = 0;
	while (std::getline(in, line)) {
		++line_number;
	}
	return line_number;
}
 ostream& operator<<(ostream& out, const ElectionResultsDatabase& votes) {
	 for (size_t i = 0;i < votes.getSections().size();++i) {
		 
		 out << votes.getSections()[i];
	 }
	 return out;
}
 istream& operator>>(std::istream& in, ElectionResultsDatabase& votes) {
//	 size_t line_number = votes.countOfLines(in);
	// size_t size = votes.getSections().size();
	// votes.resize(line_number);
	 SectionVotes createvote;
	while(in>>createvote){
		votes.addSection(createvote);


	 }
	 return in;
 }

void ElectionResultsDatabase::addResultsFromFile(const char* filename) {
	ifstream inFile(filename);
	if (inFile.is_open()) {
		inFile >>*this;
		this->setTotalVotes();
	}
}
void ElectionResultsDatabase:: addSection(SectionVotes& vote) {
	sections.push_back(vote);
}
void ElectionResultsDatabase::setTotalVotes() {
	int party1 = 0;
	int party2 = 0;
	int party3 = 0;
	for (size_t i = 0;i < sections.size();++i) {
		party1 += sections[i].votesForParty(Party::PARTY1);
		party2 += sections[i].votesForParty(Party::PARTY2);
		party3 += sections[i].votesForParty(Party::PARTY3);
	}
	parties[0] = party1;
	parties[1] = party2;
	parties[2] = party3;
}
