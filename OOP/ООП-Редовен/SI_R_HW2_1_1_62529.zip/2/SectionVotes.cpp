#include "SectionVotes.hpp"
SectionVotes::SectionVotes() {
	party1Votes = 0;
	party2Votes = 0;
	party3Votes = 0;
}
SectionVotes::SectionVotes(int party1Votes, int party2Votes, int party3Votes) {
	this->party1Votes = party1Votes;
	this->party2Votes = party2Votes;
	this->party3Votes = party3Votes;
}
int SectionVotes::votesForParty(Party party) const {
	if (party == Party::PARTY1)
		return this->party1Votes;
	if (party == Party::PARTY2)
		return this->party2Votes;
	return party3Votes;
}
void SectionVotes::setVotesForParty(Party party, int votes) {
	if (party == Party::PARTY1)
		party1Votes = votes;
	if (party == Party::PARTY2)
		party2Votes = votes;
	if (party == Party::PARTY3)
		party3Votes = votes;
}
ostream& operator<<(ostream& out, const SectionVotes& votes) {
	Party party1 = Party::PARTY1;
	Party party2 = Party::PARTY2;
	Party party3 = Party::PARTY3;
	out << votes.votesForParty(party1) << " " << votes.votesForParty(party2) << " " << votes.votesForParty(party3) << endl;
	return out;
}
istream& operator>>(std::istream& in, SectionVotes& votes) {
	int votesforparty = 0;
	Party party = Party::PARTY1;
	for (size_t i = 0;i < 3;++i) {
		in >> votesforparty;
		if (i == 0)
			party = Party::PARTY1;
		if (i == 1)
			party = Party::PARTY2;
		if (i == 2)
			party = Party::PARTY3;
		votes.setVotesForParty(party, votesforparty);
	}
	return in;
}
