#pragma once
#include <iostream>
using namespace std;
#include <vector>
// Add all other required methods and fields of the class.

class Vector4D {
    vector<double> v;
public:

    Vector4D(double, double, double, double);
    const double& operator[](size_t) const;
    double& operator[](size_t);
    friend Vector4D operator+(const Vector4D& lhs, const Vector4D& rhs);
    friend Vector4D operator-( const Vector4D& lhs, const Vector4D& rhs);
    Vector4D& operator+=(const Vector4D& lhs);
    Vector4D& operator-=(const Vector4D& lhs);
    friend Vector4D operator*(const Vector4D&,const Vector4D&);
    friend Vector4D operator/( const Vector4D&, const Vector4D&);
    friend Vector4D operator*( const Vector4D&,const double&);
    friend Vector4D operator/( const Vector4D&, const double&);
    Vector4D& operator*=(const Vector4D& lhs);
    Vector4D& operator/=(const Vector4D& lhs);
    Vector4D& operator*=(const double& number);
    Vector4D& operator/=(const double& number);
    bool operator==(const Vector4D&) const;
    bool operator!=(const Vector4D&) const;
    bool operator<(const Vector4D&) const;
    bool operator<=(const Vector4D&) const;
    bool operator>(const Vector4D&) const;
    bool operator>=(const Vector4D&) const;
    Vector4D operator-() const;
    bool operator!() const;

};
