#include "Vector4D.hpp"
Vector4D::Vector4D(double a, double b, double c, double d) {
	v.push_back(a);
	v.push_back(b);
	v.push_back(c);
	v.push_back(d);
}
double& Vector4D::operator[](size_t index) {
	return v[index];
}
const double& Vector4D::operator[](size_t index) const {
	return v[index];
}
Vector4D operator+( const Vector4D &lhs, const Vector4D& rhs) {
	Vector4D v2(lhs[0] + rhs[0], lhs[1] + rhs[1], lhs[2] + rhs[2], lhs[3] + rhs[3]);
	return v2;
}
Vector4D operator-(const Vector4D& lhs, const Vector4D& rhs) {
	Vector4D v2(lhs[0] - rhs[0], lhs[1] - rhs[1], lhs[2] - rhs[2], lhs[3] - rhs[3]);
	return v2;
}

Vector4D& Vector4D:: operator+=(const Vector4D& lhs) {
	v[0] += lhs[0];
	v[1] += lhs[1];
	v[2] += lhs[2];
	v[3] += lhs[3];
	return *this;
}
Vector4D & Vector4D::operator-=(const Vector4D& lhs) {
	v[0] -= lhs[0];
	v[1] -= lhs[1];
	v[2] -= lhs[2];
	v[3] -= lhs[3];
	return *this;
}
Vector4D operator*(const Vector4D& lhs, const Vector4D& rhs) {
	Vector4D v2(lhs[0] * rhs[0], lhs[1] * rhs[1], lhs[2] * rhs[2], lhs[3] * rhs[3]);
	return v2;

}
Vector4D operator/( const Vector4D& lhs, const Vector4D& rhs){
	Vector4D v2(lhs[0] / rhs[0], lhs[1] / rhs[1], lhs[2] / rhs[2], lhs[3] / rhs[3]);
	return v2;

}
Vector4D operator*(const Vector4D& lhs,const double& number) {
	Vector4D v2(lhs[0] * number, lhs[1] * number, lhs[2] * number, lhs[3] * number);
	return v2;
}
Vector4D operator/( const Vector4D& lhs,const double& number) {
	Vector4D v2(lhs[0] / number, lhs[1] / number, lhs[2] / number, lhs[3] / number);
	return v2;
}
Vector4D& Vector4D::operator*=(const Vector4D& lhs) {
	v[0] *= lhs[0];
	v[1] *= lhs[1];
	v[2] *= lhs[2];
	v[3] *= lhs[3];
	return *this;
}
Vector4D &Vector4D::operator/=(const Vector4D& lhs) {
	v[0] /= lhs[0];
	v[1] /= lhs[1];
	v[2] /= lhs[2];
	v[3] /= lhs[3];
	return *this;
}
Vector4D& Vector4D::operator*=( const double& number) {
	v[0] *= number;
	v[1] *= number;
	v[2] *= number;
	v[3] *= number;
	return *this;

}
Vector4D& Vector4D:: operator/=(const double& number) {
	v[0] /= number;
	v[1] /= number;
	v[2] /= number;
	v[3] /= number;
	return *this;
}
bool Vector4D::operator==(const Vector4D& other) const {
	if (v[0] == other[0] and v[1] == other[1] and v[2] == other[2] and v[3] == other[3])
		return true;
	return false;
}
bool Vector4D::operator!=(const Vector4D& other) const{
	if (*this == other)
		return false;
	return true;
}
bool Vector4D::operator<(const Vector4D& other) const{
	for (size_t i = 0;i < v.size();++i) {
		if (v[i] < other[i]) {
			return true;
		}
	}
	return false;
}
bool Vector4D::operator<=(const Vector4D& other) const {
	if (*this == other)
		return true;
	for (size_t i = 0;i < v.size();++i) {
		if (v[i] < other[i]) {
			return true;
		}
	}
	return false;
}
bool Vector4D::operator>(const Vector4D& other) const{
	for (size_t i = 0;i < v.size();++i) {
		if (v[i] > other[i]) {
			return true;	
		}
	}
	return false;
}
bool Vector4D::operator>=(const Vector4D& other) const{
	if (*this == other)
		return true;
	for (size_t i = 0;i < v.size();++i) {
		if (v[i] > other[i]) {
			return true;
		}
	}
	return false;
}
Vector4D Vector4D::operator-() const{
	Vector4D v2(v[0]* -1, v[1] * -1, v[2] * -1, v[3] * -1);
	return v2;
}
bool Vector4D:: operator!() const{
	if (v[0] == 0 and v[1] == 0 and v[2] == 0 and v[3] == 0)
		return true;
	return false;
}

