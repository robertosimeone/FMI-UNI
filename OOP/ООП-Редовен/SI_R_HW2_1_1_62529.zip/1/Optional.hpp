#pragma once
#include "Error.hpp"
// Add whatever else is required to exist in or out the class
// as well as whatever you think is good to be declared too

template <class T>
class Optional{
private:
    T element;
    bool isEmpty;
public:
    Optional();
    Optional(const T& value);

    bool is_none() const;
    T get_value() const;    
};
template <class T>
Optional<T>::Optional(): element(T()) {
    isEmpty = true; 
}
template <class T>
Optional<T>::Optional(const T& value) {
    element = value;
    isEmpty = false;
}

template <class T>
bool Optional<T>::is_none() const {
    return isEmpty;
}
template <class T>
T Optional<T>::get_value() const {
    return element;
}