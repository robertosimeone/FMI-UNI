#pragma once

// Add whatever else is required to exist in or out the class
// as well as whatever you think is good to be declared too

#include "Error.hpp"
#include "Optional.hpp"

template<class T>
class Result {
private:
    Optional <T> result;
    Optional <Error> error;
public:
    Result();
    Result(const T& result);
    Result(const std::string& error_message);
    bool operator==(const Error& error);
    bool operator==(const T & item);


    Optional<T> get_result() const;
    Optional<Error> get_error() const;

};
template <class T>
Result<T>::Result() : result(Optional<T>()) ,error(Optional<Error>()) {
}
template <class T>
Result<T>::Result(const T& result):  result(Optional<T>(result)), error(Optional<Error>()) {
   

}
template <class T>
Result<T>::Result(const std::string& error_message): result(Optional<T>()), error(Optional<Error>(error_message)) {// u have no coonstructor for optional that accepts string
    
}
template <class T>
Optional<Error> Result<T>::get_error() const {
    return error;
}
template <class T>
Optional<T> Result<T>::get_result() const {
    return result;
}
template <class T>
bool Result<T>::operator==(const Error& error) {
    if (this->error.is_none())
        return false;
    return true;
}
template <class T>
bool Result<T>::operator==(const T& item){
    if (this->result.is_none())
        return false;
    return true;
}