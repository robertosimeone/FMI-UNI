#pragma once
#include <string>
class Error {
private:
    std::string message;
public:
    Error(const std::string& message = "");
    Error& operator=(const Error& error);
    std::string get_message() const;
    void setmsg(const std::string& message);
};  