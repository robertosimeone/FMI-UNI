package com.example.chatapp.module;

public enum Status {
    ONLINE,
    OFFLINE
}
