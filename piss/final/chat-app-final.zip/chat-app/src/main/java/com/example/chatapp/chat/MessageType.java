package com.example.chatapp.chat;

public enum MessageType {
    CHAT,
    JOIN,
    LEAVE
}
